(function(){
"use strict";
const API="https://openpq-weather-next-ingest.kenzuko.workers.dev/weather-next.json";
const TZ="Asia/Ho_Chi_Minh";
const AREAS={duong_dong:"Dương Đông",an_thoi:"An Thới",north:"Bắc đảo"};
const STATE={data:null,region:"duong_dong",day:null,dayTouched:false,layer:"rain",retrievedAt:null};
const el=id=>document.getElementById(id);
const validNumber=(x,min,max)=>typeof x==="number"&&Number.isFinite(x)&&x>=min&&x<=max;
const fmt=(x,d=0)=>Number.isFinite(x)?x.toLocaleString("vi-VN",{minimumFractionDigits:d,maximumFractionDigits:d}):"--";
const local=(date,opts)=>new Intl.DateTimeFormat("vi-VN",{timeZone:TZ,...opts}).format(new Date(date));
const dateOnly=(date)=>new Intl.DateTimeFormat("en-CA",{timeZone:TZ,year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(date));
const dateOf=(str)=>new Date(str+"T12:00:00+07:00");
const n=(tag,cls,value)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(value!==undefined)e.textContent=value;return e;};
const isFresh=d=>{
 const age=Date.now()-Date.parse(d&&d.published_at);
 return !!d&&d.schema==="weather-next-shadow-v1"&&d.scope==="STAGING_ONLY"&&d.canonical===false&&d.decision_eligibility==="ABSTAIN"&&d.openpq&&["weather-next-v3-display-1","weather-next-v3-display-2"].includes(d.openpq.contract)&&d.openpq.decision==="ABSTAIN"&&["NOT_CONNECTED","PARTIAL"].includes(d.openpq.observation_readiness)&&d.openpq.areas&&Number.isFinite(age)&&age>=-120000&&age<8*3600000;
};
const area=()=>STATE.data?.openpq?.areas?.[STATE.region];
const areaTimeFresh=a=>{const age=Date.now()-Date.parse(a?.updated_at);return Number.isFinite(age)&&age>=-120000&&age<=3*3600000;};
const sourceReady=a=>areaTimeFresh(a)&&a?.availability==="REFERENCE_ONLY"&&a.decision==="ABSTAIN"&&a.current&&validNumber(a.current.temperature_2m,-10,55)&&validNumber(a.current.precipitation,0,500)&&Array.isArray(a.hours)&&Array.isArray(a.days);
const weatherSymbol=(rain,cloud,date)=>{
 const hour=date?Number(new Intl.DateTimeFormat("en-GB",{timeZone:TZ,hour:"2-digit",hour12:false}).format(new Date(date))):12;
 const night=hour<6||hour>=18;
 if(!validNumber(rain,0,1000))return "☁️";
 if(rain>=2)return "🌧️";
 if(rain>=.2)return night?"🌧️":"🌦️";
 if(cloud>=75)return "☁️";
 if(cloud>=40)return night?"☁️":"⛅";
 return night?"🌙":"☀️";
};
const category=d=>d?.category||"Đang cập nhật";
function pending(msg){
 ["metric-rain","metric-humidity","metric-wind","metric-visibility"].forEach(id=>el(id).textContent="--");
 el("hero-symbol").textContent="☁️";
 el("hero-temp").textContent="--°";el("hero-summary").textContent=msg;el("hero-desc").textContent="Không dùng số liệu cũ hoặc dữ liệu mẫu.";
 el("hero-updated").textContent="Chưa xác minh được nguồn";
 if(el("quick-verdict"))el("quick-verdict").textContent="Đang cập nhật";
 el("hero-why").textContent="Chưa có đủ dữ liệu đúng thời gian và khu vực để OpenPQ đưa ra nhận định.";
 el("today-brief").textContent="Đang chờ dữ liệu đủ điều kiện hiển thị.";
 el("today-state").textContent="Chưa xác minh";
 el("today-hours").replaceChildren(n("p","placeholder","Dữ liệu theo giờ tạm thời không khả dụng."));
 el("day-grid").replaceChildren(n("p","placeholder","Chưa có dự báo 10 ngày hợp lệ."));
 el("selected-day-detail").firstElementChild.textContent="Không có dữ liệu theo giờ được xác minh.";
 el("day-detail-hours").replaceChildren();
 el("wave").textContent="--";el("wave-period").textContent="--";
 el("marine-brief").textContent="Không công bố số liệu sóng khi chưa xác minh.";
 el("signal-morning").textContent="Chưa xác minh";el("signal-evening").textContent="Chưa xác minh";
 el("signal-morning-detail").textContent="Không có dữ liệu theo giờ hợp lệ";
 el("signal-evening-detail").textContent="Không có dữ liệu theo giờ hợp lệ";
}
function freshAirport(){
 const obs=STATE.data?.openpq?.observations?.airport_vvpq;
 if(!obs||obs.data_class!=="ACTUAL_STATION_ONLY"||obs.station_id!=="VVPQ")return null;
 const age=Date.now()-Date.parse(obs.observed_at);
 if(!Number.isFinite(age)||age< -120000||age>75*60000||!validNumber(obs.temperature_c,-10,55))return null;
 return obs;
}
function airportSky(obs){
 const cov=Array.isArray(obs.cloud_cover_codes)?obs.cloud_cover_codes:[];
 if(cov.includes("OVC"))return {text:"Nhiều mây tại sân bay",symbol:"☁️",bright:false};
 if(cov.includes("BKN"))return {text:"Nhiều mây tại sân bay",symbol:"🌥️",bright:false};
 if(cov.includes("SCT"))return {text:"Mây rải rác tại sân bay",symbol:"⛅",bright:true};
 if(cov.includes("FEW")||cov.includes("SKC")||cov.includes("CLR")||false)return {text:"Trời ít mây tại sân bay",symbol:"🌤️",bright:true};
 return {text:"Quan trắc sân bay mới cập nhật",symbol:"☁️",bright:false};
}
function renderMetrics(obs,model){
 const metar=!!obs;
 const dew=obs?.dewpoint_c, temp=obs?.temperature_c;
 const rh=metar&&validNumber(dew,-30,55)&&validNumber(temp,-10,55)?
   100*Math.exp((17.625*dew)/(243.04+dew)-(17.625*temp)/(243.04+temp)):null;
 const metarRaw=obs?.raw_observation||"";
 const clear=metar&&!/\b(RA|DZ|TS|SHRA|SN)\b/.test(metarRaw);
 el("metric-rain").textContent=metar?(clear?"Không ghi nhận":"Có hiện tượng"):(validNumber(model.precipitation,0,500)?fmt(model.precipitation,1)+" mm":"--");
 el("metric-humidity").textContent=metar?(rh!==null?Math.round(rh)+"%*":"--"):(validNumber(model.cloud_cover,0,100)?Math.round(model.cloud_cover)+"% mây":"--");
 el("metric-wind").textContent=metar&&validNumber(obs.wind_speed_kmh,0,250)?Math.round(obs.wind_speed_kmh)+" km/h":validNumber(model.wind_speed_10m,0,250)?Math.round(model.wind_speed_10m)+" km/h":"--";
 el("metric-visibility").textContent=metar&&/\s9999\s/.test(metarRaw)?">10 km":"--";
}
function render(){
 const a=area();el("area-label").textContent=AREAS[STATE.region];
 document.querySelectorAll("[data-area]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.area===STATE.region)));
 renderSourceHealth();
 if(!sourceReady(a)){pending("Đang cập nhật thời tiết");renderMarine(a||{});renderMethod();window.openpqDisplaySnapshot={data:STATE.data,region:STATE.region};window.dispatchEvent(new CustomEvent("openpq:render",{detail:window.openpqDisplaySnapshot}));return;}
 const current=a.current,daily=a.days[0],airport=freshAirport(),sky=airport?airportSky(airport):null;
 const useAirport=false; // Airport observation stays in its own station card.
 renderMetrics(useAirport?airport:null,current);
 el("hero-temp").textContent=Math.round(useAirport?airport.temperature_c:current.temperature_2m)+"°";
 el("hero-symbol").textContent=useAirport?sky.symbol:weatherSymbol(current.precipitation,current.cloud_cover,new Date());
 el("hero-summary").textContent=useAirport?sky.text:"Dữ liệu dự báo tại "+AREAS[STATE.region];
 el("hero-desc").textContent=useAirport
  ?"Quan trắc trực tiếp tại sân bay Phú Quốc, gần Dương Đông; không đại diện cho toàn đảo."
  :"Số liệu mô hình được OpenPQ xử lý, chưa có quan trắc riêng tại khu vực này.";
 el("hero-updated").textContent=(useAirport?"Quan trắc "+local(airport.observed_at,{hour:"2-digit",minute:"2-digit"}):"Mô hình tại "+local(a.updated_at,{hour:"2-digit",minute:"2-digit"}))+" · "+local(a.updated_at,{day:"2-digit",month:"2-digit"});
 el("hero-why").textContent=useAirport
  ?"Sân bay ghi nhận "+Math.round(airport.temperature_c)+"°C, "+sky.text.toLowerCase()+", gió "+fmt(airport.wind_speed_kmh,0)+" km/h. Đây là dữ liệu đo tại sân bay; dự báo mưa cần đối chiếu thêm trạm mưa khu vực."
  :"Đây là dự báo cho ô lưới "+AREAS[STATE.region]+". Dữ liệu quan trắc tại chỗ chưa có; không suy đoán thời tiết cả đảo.";
 const verdict=document.getElementById("quick-verdict");
 if(verdict)verdict.textContent=useAirport&&sky.bright?"Nắng, ít mây theo quan trắc":"Tín hiệu từ OpenPQ Weather";
 el("today-brief").textContent=useAirport
  ?sky.text+" · các ô phía dưới là diễn biến dự báo, có thể khác trời thực tế."
  :daily?(category(daily)+" · dự báo theo khung giờ."): "Đang cập nhật dự báo theo giờ.";
 el("today-state").textContent=useAirport?"Quan trắc sân bay mới":"Dự báo OpenPQ";
 const decisionBadge=document.querySelector(".decision .panel-title .mini-status");
 if(decisionBadge)decisionBadge.textContent=useAirport?"Quan trắc hiện tại":"Theo khu vực";

 const decisions=document.querySelectorAll(".decision-option");
 if(decisions.length>=3){
  decisions[0].querySelector("b").textContent=useAirport&&sky.bright?"Ngoài trời · Nắng tại sân bay":"Ngoài trời · Xem từng khu vực";
  const station=STATE.region==="duong_dong"?STATE.data.openpq.observations?.synop_48917:null;
  const stationFresh=station?.status==="CURRENT"&&Date.now()-Date.parse(station.observed_at)<=240*60000;
  decisions[0].querySelector("p").textContent=stationFresh?"Có số đo tại trạm Dương Đông; xem mưa dự báo theo giờ và bản tin KTTV.":useAirport?"Trời ít mây tại sân bay; xem số đo trạm và bản tin KTTV trước khi di chuyển.":"Chưa có số đo tại khu vực đã chọn.";
  decisions[1].querySelector("b").textContent="Đi biển · Kiểm tra tuyến";
  decisions[1].querySelector("p").textContent="Dự báo sóng có sẵn; chưa thay thế kiểm tra thực tế tuyến và cano.";
  decisions[2].querySelector("b").textContent=useAirport&&sky.bright?"Chụp ảnh · Có ánh sáng tại sân bay":"Chụp ảnh · Xem ảnh mây";
  decisions[2].querySelector("p").textContent="Điều kiện thay đổi theo địa điểm và thời điểm.";
 }
 renderToday(a);renderTen(a);renderMarine(a);renderMethod();window.openpqDisplaySnapshot={data:STATE.data,region:STATE.region};window.dispatchEvent(new CustomEvent("openpq:render",{detail:window.openpqDisplaySnapshot}));
}
function hourChart(hours,mode){
 const ns="http://www.w3.org/2000/svg",width=hours.length*70,height=148;
 const svg=document.createElementNS(ns,"svg");svg.setAttribute("viewBox",`0 0 ${width} ${height}`);svg.setAttribute("width",width);svg.setAttribute("height",height);svg.setAttribute("role","img");
 const metric=mode==='wind'?'wind_kmh':mode==='cloud'?'cloud_percent':mode==='rain'?'rain_mm':'temperature';
 const unit=mode==='wind'?' km/h':mode==='cloud'?'%':mode==='rain'?' mm':'°C';
 svg.setAttribute("aria-label",'Diễn biến '+({temperature:'nhiệt độ',rain:'mưa dự báo',wind:'gió dự báo',cloud:'mây dự báo'}[mode])+' từng giờ, dữ liệu mô hình tham khảo');
 const node=(tag,attrs,text)=>{const e=document.createElementNS(ns,tag);Object.entries(attrs).forEach(([k,v])=>e.setAttribute(k,v));if(text!==undefined)e.textContent=text;svg.append(e);return e};
 const values=hours.map(h=>h[metric]).filter(Number.isFinite),lo=mode==='temperature'?Math.min(...values)-2:0,hi=Math.max(lo+1,...values)+(mode==='temperature'?2:0);
 const y=v=>108-(v-lo)/(hi-lo)*72;
 for(const yy of [36,72,108])node('line',{x1:0,x2:width,y1:yy,y2:yy,stroke:'#e8eff6'});
 let segment=[];const flush=()=>{if(segment.length)node('polyline',{points:segment.join(' '),fill:'none',stroke:'#1978d4','stroke-width':2.5});segment=[]};
 hours.forEach((h,i)=>{const x=i*70+35,v=h[metric];if(i&&Date.parse(h.time)-Date.parse(hours[i-1].time)>3600000)flush();
  if(i&&dateOnly(h.time)!==dateOnly(hours[i-1].time)){node('line',{x1:i*70,x2:i*70,y1:0,y2:height,stroke:'#aac5df','stroke-dasharray':'4 4'});node('text',{x:i*70+5,y:14,fill:'#476b8c','font-size':10},local(h.time,{day:'2-digit',month:'2-digit'}))}
  if(!Number.isFinite(v)){flush();return}
  if(mode==='rain'){const bar=node('rect',{x:x-12,y:y(v),width:24,height:Math.max(0,108-y(v)),rx:4,fill:'#37a9ec'});const title=document.createElementNS(ns,'title');title.textContent=local(h.time,{hour:'2-digit',minute:'2-digit'})+': '+fmt(v,1)+unit;bar.append(title)}
  else{segment.push(`${x},${y(v)}`);node('circle',{cx:x,cy:y(v),r:3,fill:'#1978d4'})}
  node('text',{x,y:y(v)-10,'text-anchor':'middle',fill:'#173d60','font-size':12,'font-weight':600},fmt(v,mode==='temperature'||mode==='cloud'?0:1));
 });flush();
 node('text',{x:8,y:140,fill:'#597892','font-size':10},mode==='rain'?'Lượng mưa mỗi giờ (mm)':'Dự báo '+unit.trim());
 return svg;
}
function renderToday(a){
 const mode=STATE.hourMetric||'temperature';
 document.querySelectorAll('[data-hour-metric]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.hourMetric===mode)));
 const start=Math.floor(Date.now()/3600000)*3600000;
 const hours=[...new Map(a.hours.filter(h=>Number.isFinite(Date.parse(h.time))&&Date.parse(h.time)>=start&&Date.parse(h.time)<start+24*3600000&&(STATE.hourWindow!=='today'||dateOnly(h.time)===dateOnly(Date.now()))).map(h=>[h.time,h])).values()].sort((x,y)=>Date.parse(x.time)-Date.parse(y.time));
 document.querySelectorAll('[data-hour-window]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.hourWindow===(STATE.hourWindow||'24h'))));
 el('hour-window-note').textContent=(STATE.hourWindow==='today'?'Còn lại hôm nay':'Giờ hiện tại và 23 giờ tiếp theo')+' · Lướt ngang để xem tiếp';
 const previousScroll=el("today-hours").scrollLeft;
 el("today-hours").replaceChildren();
 if(!hours.length)el("today-hours").append(n("p","placeholder","Chưa có dữ liệu giờ sắp tới."));
 const chartHours=hours.filter(h=>validNumber(h.temperature,-10,55)&&validNumber(h.rain_mm,0,500));
 const strip=n("div","forecast-strip");
 if(chartHours.length){strip.append(hourChart(chartHours,mode));el("today-hours").append(strip)}
 const tiles=n("div","forecast-tiles");strip.append(tiles);
 hours.forEach(h=>{
  if(!validNumber(h.temperature,-10,55)||!validNumber(h.rain_mm,0,500))return;
  const e=n("div","hour-tile");
  e.append(n("small","",local(h.time,{hour:"2-digit",minute:"2-digit"})));
  if(dateOnly(h.time)!==dateOnly(Date.now()))e.append(n("small","","Ngày mai"));
  e.append(n("div","icon",weatherSymbol(h.rain_mm,h.cloud_percent,h.time)));
  const value=mode==='rain'?fmt(h.rain_mm,1)+' mm':mode==='wind'?fmt(h.wind_kmh,1)+' km/h':mode==='cloud'?fmt(h.cloud_percent,0)+'%':Math.round(h.temperature)+'°';
  e.append(n("b","",value));
  e.append(n("div","raininfo","Mưa dự báo "+fmt(h.rain_mm,1)+" mm"));
  tiles.append(e);
 });
 el("today-hours").scrollLeft=previousScroll;
 function describe(from,to){
  const set=a.hours.filter(h=>{
   const ms=Date.parse(h.time);
   if(!Number.isFinite(ms))return false;
   const hour=Number(new Intl.DateTimeFormat("en-GB",{timeZone:TZ,hour:"2-digit",hour12:false}).format(new Date(ms)));
   return dateOnly(ms)===dateOnly(Date.now())&&hour>=from&&hour<to;
  });
  if(!set.length)return{title:"Chưa có dữ liệu khung giờ",detail:"Không suy diễn điều kiện"};
  const sum=set.reduce((total,h)=>total+(validNumber(h.rain_mm,0,500)?h.rain_mm:0),0);
  return{title:from+"–"+to+"h · "+(sum>=5?"Mưa trong dự báo":sum>=.5?"Có tín hiệu mưa":"Ít mưa trong mô hình"),detail:"Lượng mưa dự báo "+fmt(sum,1)+" mm · chưa kiểm chứng bằng số đo tại chỗ"};
 }
 const am=describe(11,14),pm=describe(16,19);
 el("signal-morning").textContent=am.title;el("signal-morning-detail").textContent=am.detail;
 el("signal-evening").textContent=pm.title;el("signal-evening-detail").textContent=pm.detail;
}
function renderTen(a){
 el("day-grid").replaceChildren();
 const rows=a.days.filter(d=>d.date>=dateOnly(Date.now())&&d.status==="MODEL_REFERENCE"&&/^\d{4}-\d{2}-\d{2}$/.test(d.date)).slice(0,10);
 if(!rows.length){el("day-grid").append(n("p","placeholder","Chưa có dự báo dài hạn được phát hành."));return;}
 if(!rows.some(x=>x.date===STATE.day))STATE.day=rows[0].date;
 const lows=rows.map(d=>d.min_c).filter(Number.isFinite),highs=rows.map(d=>d.max_c).filter(Number.isFinite);
 const rangeMin=Math.min(...lows)-1,rangeSpan=Math.max(1,Math.max(...highs)+1-rangeMin);
 rows.forEach(d=>{
  const good=validNumber(d.min_c,-10,55)&&validNumber(d.max_c,-10,55)&&validNumber(d.rain_mm,0,1000)&&d.coverage_hours>=6;
  const b=n("button","day-tile");b.type="button";b.dataset.day=d.date;b.setAttribute("aria-pressed",String(d.date===STATE.day));b.disabled=!good;
  if(good){b.dataset.rainLevel=d.rain_mm>=10?"wet":d.rain_mm>=1?"mixed":"dry";b.style.setProperty("--day-rain",Math.min(100,d.rain_mm/20*100)+"%")}
  b.append(n("small","",local(dateOf(d.date),{weekday:"short",day:"2-digit",month:"2-digit"})));
  b.append(n("span","symbol",weatherSymbol(d.rain_mm>=5?2:d.rain_mm>=1?.4:0, d.category==="Nhiều mây"?90:45)));
  b.append(n("b","",good?d.max_c+"°":"--"));
  b.append(n("div","low",good?d.min_c+"°":"Chưa xác minh"));
  if(good){const range=n("div","day-temperature-range");range.style.setProperty("--range-start",Math.max(0,(d.min_c-rangeMin)/rangeSpan*100)+"%");range.style.setProperty("--range-width",Math.max(4,(d.max_c-d.min_c)/rangeSpan*100)+"%");range.setAttribute("aria-label",d.min_c+" đến "+d.max_c+" độ C");range.append(n("span",""));b.append(range)}
  b.append(n("em","",good?"Mưa "+fmt(d.rain_mm,0)+" mm":"Không phát hành"));
  b.addEventListener("click",()=>{STATE.day=d.date;STATE.dayTouched=true;renderTen(a);window.openpqDisplaySnapshot={data:STATE.data,region:STATE.region};window.dispatchEvent(new CustomEvent("openpq:render",{detail:window.openpqDisplaySnapshot}));});
  el("day-grid").append(b);
 });
 const day=rows.find(x=>x.date===STATE.day);
 el("ten-note").textContent="10 ngày từ OpenPQ Weather Engine · xu hướng mô hình tham khảo. Ngày có ít hơn 24 giờ dữ liệu là ngày chỉ bao phủ một phần. Không dùng để xác nhận điều kiện đi biển.";
 renderDayDetail(day,a.hours||[]);
}
function renderDayDetail(day,hours){
 el("selected-day-detail").hidden=!STATE.dayTouched;
 const root=el("selected-day-detail");el("day-detail-hours").replaceChildren();
 if(!day){root.firstElementChild.textContent="Chưa có ngày hợp lệ";return;}
 root.firstElementChild.textContent=local(dateOf(day.date),{weekday:"long",day:"2-digit",month:"2-digit"})+" · "+category(day)+" · "+day.coverage_hours+" khung giờ mô hình";
 const list=hours.filter(h=>dateOnly(h.time)===day.date&&validNumber(h.temperature,-10,55)&&validNumber(h.rain_mm,0,500));
 if(!list.length){el("day-detail-hours").append(n("small","","Chi tiết theo giờ của ngày này chưa đủ điều kiện hiển thị."));return;}
 list.forEach(h=>{
  const tile=n("div","day-hour");
  tile.append(n("small","",local(h.time,{hour:"2-digit",minute:"2-digit"})));
  tile.append(n("span","",weatherSymbol(h.rain_mm,h.cloud_percent,h.time)));
  tile.append(n("b","",fmt(h.temperature,0)+"°"));
  tile.append(n("small","","Mưa "+fmt(h.rain_mm,1)+" mm"));
  el("day-detail-hours").append(tile);
 });
}
function renderMarine(a){
 el("marine-area").textContent=AREAS[STATE.region]+" · ô lưới biển";
 const sea=a.marine||{};
 const age=Date.now()-Date.parse(sea.grid_valid_at);
 if(Number.isFinite(age)&&age>=-120000&&age<=3*3600000&&sea.status==="MODEL_REFERENCE"&&sea.decision==="ABSTAIN"&&validNumber(sea.wave_height_m,0,30)){
  el("wave").textContent=fmt(sea.wave_height_m,2)+" m";
  el("wave-period").textContent=validNumber(sea.period_s,0,50)?fmt(sea.period_s,1)+" s":"--";
  el("marine-brief").textContent="Sóng dự báo theo khu vực lưới · chưa xác minh trên tuyến cano thực tế.";
 }else{
  el("wave").textContent="--";el("wave-period").textContent="--";
  el("marine-brief").textContent="Chưa có dữ liệu sóng đủ điều kiện.";
 }
}
function renderSourceHealth(){
 const root=el("source-health-grid");if(!root)return;root.replaceChildren();
 const health=STATE.data?.openpq?.source_health||{};
 const summary=document.querySelector("#source-health summary span");if(summary)summary.textContent=STATE.data?Object.keys(health).length+" mục nguồn · Xem thời điểm":"Nguồn đang cập nhật";
 const labels={CURRENT:"Có dữ liệu",MODEL_REFERENCE:"Dự báo tham khảo",STALE:"Cần cập nhật",NO_NEW_SAMPLE:"Chưa có mẫu đo mới",UNAVAILABLE:"Chưa nhận được",FUTURE_INVALID:"Lỗi thời điểm",WITHHELD_UNVERIFIED:"Tạm ngừng · chưa chứng minh hiệu quả",UNVERIFIED:"Cần kiểm chứng",NOT_CONNECTED:"Chưa kết nối"};
 const known=["vvpq","synop_48917","vrain_cua_can","vrain_bai_thom","vrain_an_thoi","himawari","gefs","radar","ecmwf_duong_dong","marine_duong_dong","ecmwf_an_thoi","marine_an_thoi","ecmwf_north","marine_north","lightning"];
 for(const key of known){
  const h=health[key]||{source:key,status:"UNAVAILABLE"};
  const row=n("div","source-health-row");
  row.append(n("b","",h.source));
  let line=labels[h.status]||h.status;
  if(h.source_time&&Number.isFinite(Date.parse(h.source_time)))line+=" · "+local(h.source_time,{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"});
  row.append(n("small","",line));
  const airport=key==="vvpq"?freshAirport():null;
  if(airport&&h.status==="CURRENT")row.append(n("span","",fmt(airport.temperature_c,1)+"°C · "+airportSky(airport).text));
  const synop=STATE.data?.openpq?.observations?.synop_48917;
  if(key==="synop_48917"&&h.status==="CURRENT"&&validNumber(synop?.values?.air_temperature_c,-10,55))row.append(n("span","",fmt(synop.values.air_temperature_c,1)+"°C · trạm Dương Đông"));
  row.dataset.source=key;row.dataset.status=h.status;
  root.append(row);
 }
}
function renderMethod(){
 const d=STATE.data;
 el("source-details").textContent="Xuất bản "+local(d.published_at,{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"})+" · dữ liệu tổng hợp bởi OpenPQ Weather Engine · 3 khu vực · 10 ngày mô hình · trạng thái quyết định ABSTAIN. Bản staging, không phải /weather chính thức.";
}
async function refresh(){
 if(inFlight)return;inFlight=true;
 try{
  const r=await fetch(API+"?v="+Date.now(),{cache:"no-store",signal:AbortSignal.timeout(15000)});
  if(!r.ok)throw new Error("Không lấy được bản cập nhật ("+r.status+")");
  const obj=await r.json();
  if(!isFresh(obj))throw new Error("Dữ liệu không đạt hợp đồng OpenPQ hoặc đã quá hạn.");
  if(obj.openpq.hourly_columns){
   const columns=obj.openpq.hourly_columns;
   if(JSON.stringify(columns)!==JSON.stringify(['time','temperature','rain_mm','wind_kmh','cloud_percent']))throw Error('Unknown hourly encoding');
   Object.values(obj.openpq.areas).forEach(a=>{a.hours=a.hours.map(h=>Array.isArray(h)?Object.fromEntries(columns.map((k,i)=>[k,h[i]])):h)});
  }
  STATE.data=obj;STATE.retrievedAt=Date.now();render();
 }catch(e){
  STATE.data=null;window.openpqDisplaySnapshot={data:null,region:STATE.region};window.dispatchEvent(new CustomEvent("openpq:render",{detail:window.openpqDisplaySnapshot}));pending("Chưa có dữ liệu đáng tin");renderSourceHealth();
  el("hero-why").textContent="Nguồn dữ liệu đang gián đoạn hoặc không đủ điều kiện. OpenPQ không hiển thị số liệu dự báo cũ. "+e.message;
  el("source-details").textContent="Không nhận được bản dữ liệu OpenPQ đạt kiểm tra nguồn và độ mới.";
 }finally{inFlight=false;}
}
el("area-buttons").addEventListener("click",e=>{
 const b=e.target.closest("[data-area]");if(!b||!AREAS[b.dataset.area])return;
 el("today-hours").scrollLeft=0;STATE.region=b.dataset.area;STATE.day=null;STATE.dayTouched=false;render();
});
el("why-button").addEventListener("click",()=>{
 el("methods").scrollIntoView({behavior:"smooth",block:"center"});
 el("methods").querySelector("details").open=true;
});
document.getElementById('hour-controls')?.addEventListener('click',e=>{const b=e.target.closest('[data-hour-metric]');if(!b)return;STATE.hourMetric=b.dataset.hourMetric;const a=area();if(sourceReady(a))renderToday(a)});
document.querySelectorAll('[data-hour-window]').forEach(b=>b.addEventListener('click',()=>{STATE.hourWindow=b.dataset.hourWindow;el('today-hours').scrollLeft=0;const a=area();if(sourceReady(a))renderToday(a)}));
let inFlight=false;
pending("Đang cập nhật");refresh();
function checkFreshness(){
 if(!STATE.data)return;
 const hours=el('today-hours').scrollLeft,days=el('day-grid').scrollLeft;
 if(!isFresh(STATE.data)){STATE.data=null;pending('Dữ liệu đã quá hạn');renderSourceHealth();window.openpqDisplaySnapshot={data:null,region:STATE.region};window.dispatchEvent(new CustomEvent('openpq:render',{detail:window.openpqDisplaySnapshot}));return;}
 render();el('today-hours').scrollLeft=hours;el('day-grid').scrollLeft=days;
}
setInterval(()=>{if(document.visibilityState==='visible')checkFreshness()},20000);
setInterval(()=>{if(document.visibilityState==="visible")refresh();},5*60*1000);
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible"){checkFreshness();if(Date.now()-(STATE.retrievedAt||0)>3*60*1000)refresh();}});
})();
