(()=>{"use strict";
const $=id=>document.getElementById(id),finite=x=>typeof x==='number'&&Number.isFinite(x);
let snapshot=null,region='duong_dong',view='weekly';
const fmt=(v,n=1)=>finite(v)?v.toLocaleString('vi-VN',{maximumFractionDigits:n}):'--';
const date=s=>{const d=new Date(s+'T00:00:00Z');return Number.isFinite(d.getTime())?new Intl.DateTimeFormat('vi-VN',{timeZone:'UTC',day:'2-digit',month:'2-digit'}).format(d):'--'};
const signed=v=>(v>0?'+':'')+fmt(v);
const stamp=s=>new Intl.DateTimeFormat('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(s));
const fresh=(s,h)=>{const a=Date.now()-Date.parse(s);return Number.isFinite(a)&&a>=-120000&&a<=h*3600000};
function render(){
 const root=$('longrange-content'),note=$('longrange-note');if(!root)return;root.replaceChildren();
 document.querySelectorAll('[data-outlook-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.outlookView===view)));
 const op=snapshot?.openpq;if(!op){note.textContent='Nguồn đang cập nhật; chưa có dữ liệu đủ điều kiện.';return}
 if(view==='history'){
  const a=op.areas?.[region],history=a?.year_context;
  if(history?.status!=='REANALYSIS_REFERENCE'||!fresh(history.fetched_at,36)||!history.rows?.length){note.textContent='Chưa có chuỗi cùng kỳ năm trước đủ điều kiện.';return}
  const table=document.createElement('table');table.className='year-context-table';
  const head=document.createElement('thead');const tr=document.createElement('tr');
  for(const t of ['Ngày','ECMWF sắp tới','ERA5 năm trước']){const th=document.createElement('th');th.textContent=t;tr.append(th)}head.append(tr);table.append(head);
  const body=document.createElement('tbody');
  for(const row of history.rows){
   const upcoming=a.days?.find(d=>d.date.slice(5)===row.date.slice(5));if(!upcoming)continue;
   const r=document.createElement('tr');
   for(const t of [date(upcoming.date)+' · '+upcoming.date.slice(0,4)+' / '+row.date.slice(0,4),fmt(upcoming.max_c)+'° / '+fmt(upcoming.min_c)+'° · '+fmt(upcoming.rain_mm)+' mm'+(upcoming.coverage_hours===24?'':' · thiếu giờ'),fmt(row.high_c)+'° / '+fmt(row.low_c)+'° · '+fmt(row.rain_mm)+' mm']){const td=document.createElement('td');td.textContent=t;r.append(td)}
   body.append(r);
  }table.append(body);root.append(table);
  note.textContent='ERA5 tái phân tích cùng kỳ '+history.rows[0].date.slice(0,4)+' tại ô lưới '+fmt(history.grid_lat,2)+'N, '+fmt(history.grid_lon,2)+'E. Hai cột khác nguồn và ô lưới; dùng làm bối cảnh, không phải số đo trạm hoặc đánh giá độ chính xác. Tra cứu '+stamp(history.fetched_at)+'.';return;
 }
 const source=op[view==='weekly'?'seasonal_weekly':'seasonal_monthly'],ttl=view==='weekly'?36:192;
 if(source?.status!=='MODEL_REFERENCE'||!fresh(source.fetched_at,ttl)||!source.rows?.length){note.textContent='Dự báo '+(view==='weekly'?'tuần':'tháng')+' đang cập nhật.';return}
 const list=document.createElement('div');list.className='outlook-grid';
 for(const r of source.rows){
  const card=document.createElement('article');card.className='outlook-card';
  const start=r.period_start,until=new Date(r.period_end_exclusive+'T00:00:00Z');until.setUTCDate(until.getUTCDate()-1);
  const title=document.createElement('b');title.textContent=view==='weekly'?date(start)+' - '+date(until.toISOString().slice(0,10)):'Tháng '+Number(start.slice(5,7))+'/'+start.slice(0,4);
  const temp=document.createElement('strong');temp.textContent=fmt(r.temperature_2m_mean)+'°C';
  const rain=document.createElement('p');rain.textContent=fmt(r.precipitation_mean)+' mm / '+(view==='weekly'?'tuần':'cả tháng');
  const anomaly=document.createElement('small');anomaly.textContent='So với nền mô hình: nhiệt '+signed(r.temperature_2m_anomaly)+'°C · mưa '+signed(r.precipitation_anomaly)+' mm';
  card.append(title,temp,rain,anomaly);list.append(card);
 }root.append(list);
 note.textContent=source.source+' · ô lưới vùng Phú Quốc khoảng 36 km, chưa hiệu chỉnh tại đảo. Chênh lệch so với khí hậu quá khứ của chính mô hình, không so với ERA5 bên trên. Kỳ UTC. '+(view==='monthly'?'Tháng bao gồm cả phần đã qua. ':'')+'Tra cứu '+stamp(source.fetched_at)+'; kỳ khởi tạo chưa xác minh. Không dùng để chọn giờ đi biển.';
}
const duplicate=document.getElementById('future'),detail=document.getElementById('future-detail');if(duplicate&&detail){document.querySelector('#methods .method-body').append(detail);duplicate.remove();}
document.querySelectorAll('[data-outlook-view]').forEach(b=>b.addEventListener('click',()=>{view=b.dataset.outlookView;render()}));
window.addEventListener('openpq:render',e=>{snapshot=e.detail.data;region=e.detail.region;render()});
if(window.openpqDisplaySnapshot){snapshot=window.openpqDisplaySnapshot.data;region=window.openpqDisplaySnapshot.region;render()}
})();
