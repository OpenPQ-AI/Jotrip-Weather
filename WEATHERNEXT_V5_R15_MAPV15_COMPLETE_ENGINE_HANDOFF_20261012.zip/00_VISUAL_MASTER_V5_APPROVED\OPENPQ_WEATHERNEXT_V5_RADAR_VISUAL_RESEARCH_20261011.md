# OPENPQ WEATHERNEXT V5 - VISUAL MASTER & RADAR/OBSERVATION RESEARCH

**Ngày:** 11/10/2026 | **Trạng thái:** Nghiên cứu / handoff, không thay đổi production

## A. Quyết định

- V5 là **Visual Master**. Bám sát bố cục desktop và mobile đã duyệt; không thiết kế lại concept.
- Đích UX: giao diện khớp bố cục, hệ màu, nhịp điệu, icon, các nhóm thẻ và chuyển động của V5. Không bảo đảm từng pixel ảnh AI do mockup có ký tự/kiến trúc/vùng mưa tưởng tượng.
- **Chỉ nghiên cứu visual và frontend.** Không cập nhật Weather Engine, ingest, API, schema, CMS, Core V1.2, DNS, scheduler; không merge/deploy production.
- Ảnh nền phải là ảnh Phú Quốc thật có quyền sử dụng; không dùng kiến trúc/cáp treo/cầu hôn do AI tự dựng làm bằng chứng địa lý.
- Tách rạch ròi OBSERVED RADAR, OBSERVED SATELLITE, ACTUAL GROUND, MODEL FORECAST, MODEL MARINE, DEMO/UNAVAILABLE.

## B. Kết quả kiểm tra code (read-only)

1. `kenzuko/jotrip-home`, branch `feat/weather-next-independent-20261008`, thư mục `weather-next/` là candidate độc lập. PR #378 vẫn là DRAFT/BLOCKED theo báo cáo 08/10; không được merge main để preview.
2. `contracts.mjs` WeatherNext đọc 6 role canonical `current`, `compact`, `forecast`, `marine`, `cloud`, `meta`; kiểm tra tuổi nguồn, receipt, phạm vi và phân biệt đo thực/model. UI hiện tại là card/text, chưa có radar map hoàn chỉnh.
3. `kenzuko/Jotrip-Weather/spatial-lab.js` từng có bản đồ Leaflet, canvas, RainViewer frames, timeline, điểm đo VRain. `weather-scene-v3.js` có các lớp quan trắc Himawari và trường màu/particle. Có thể tham khảo cách dựng **giao diện**, nhưng không được copy dependency vào runtime WeatherNext hoặc bypass canonical.
4. Snapshot trong `kenzuko/Jotrip-Weather/data/weather-runtime/` ngày 11/10/2026:
   - `compact.json`: sampled Himawari 2026-10-11T06:30:20Z; các chỉ số tại 8 điểm. Đây là snapshot GitHub, **không phải chứng thực API production hiện còn mới**.
   - `current.json`: groundtruth rainfall chứa 3 trạm VRain An Thới, Cửa Cạn, Bãi Thơm với tình trạng nguồn/timestamp khác nhau; một điểm QC PASS không có nghĩa đủ bằng chứng mưa tức thời.
   - `forecast.json`: ECMWF spatial 25 frames, 35 cells/frame, requested_grid_deg=0.5 (~55km kinh/vĩ ở vùng này), không thể dùng để chứng minh chi tiết mưa ở cấp phố.
   - `marine.json`: Copernicus marine cells, native_resolution_deg ~0.0833 (khoảng 9km vĩ), chỉ mô hình vùng biển, không phải quan trắc sát bờ.
   - `cloud.json` khá lớn (~1.32 MB); cần kiểm tra khả năng khung hình địa lý & tải trên iPhone trước khi dùng trực tiếp; chưa xác minh hết nội dung payload này.
5. Đường API public openphuquoc.com/weather/... không đọc được qua công cụ web lần kiểm tra hiện tại, vì vậy **không đưa ra khẳng định LIVE/PASS** từ snapshot repo.

## C. Nguồn tham khảo và quyết định khả thi

**MapLibre GL JS:** lựa chọn mạnh cho frontend basemap + raster/weather + canvas/WebGL + animate frame; giấy phép BSD-3-Clause (thư viện không phải giấy phép cho dữ liệu tile/basemap). Giữ Leaflet làm giải pháp dự phòng nếu benchmark iPhone không đạt.

**RainViewer:** bản Weather cũ gọi `https://api.rainviewer.com/public/weather-maps.json` và dùng tile trực tiếp. Từ 01/01/2026 free API chỉ còn 2h radar quá khứ, không có nowcast tương lai/satellite IR, chỉ Universal Blue, max zoom 7, giới hạn 100 requests/IP/phút. Điều khoản 2026 hướng đến cá nhân/giáo dục, không nên mặc định được dùng cho OpenPQ/JoTrip commercial production; phải xác minh quyền sử dụng và phủ Phú Quốc. Thích hợp nghiên cứu kỹ thuật cục bộ theo điều khoản, **không làm phụ thuộc mặc định production**.

**JMA Himawari-9 qua NOAA Open Data:** nguồn công khai với điều khoản sử dụng rõ, cần ghi công và ghi rõ nếu xử lý/chỉnh sửa. Có thể dùng như nguồn cho **MÂY VỆ TINH**, không biến thành radar mưa. Dữ liệu thô lớn cần pipeline hợp lệ riêng; không yêu cầu thay pipeline trong phạm vi nghiên cứu này. Tận dụng canon sẵn có trước.

**NCHMF radar Việt Nam:** cổng nhà nước có mục Radar, nhưng từ việc thấy mục này không thể suy ra đã có API tile công khai, quyền tích hợp hay vùng phủ radar tại Phú Quốc. Chỉ nâng lên ứng viên sau xác minh URL, license, metadata, georeference, coverage và độ trễ.

**NO FAKE:** nếu vùng Phú Quốc không có radar thật tại thời điểm đang xem, để nền bản đồ sạch, chỉ chuyển sang “Mây vệ tinh” hoặc “Mưa dự báo” có nhãn nguồn rõ. Không vẽ mưa màu chỉ để giống mockup.

Nguồn:
- https://www.rainviewer.com/api/transition-faq.html
- https://www.rainviewer.com/api.html
- https://www.rainviewer.com/api/weather-maps-api.html
- https://registry.opendata.aws/noaa-himawari/
- https://www.jma.go.jp/jma/jma-eng/satellite/dissemination.html
- https://maplibre.org/maplibre-gl-js/docs/examples/
- https://maplibre.org/maplibre-gl-js/docs/examples/animate-a-series-of-images/
- https://nchmf.gov.vn/kttvsiteE/en-US/2/image-rain-map-m4.html

## D. Frontend layout spec V5

**Desktop:** một header nav duy nhất; hero toàn cảnh Phú Quốc thật, giảm chữ/hình thừa, nhiệt độ và quyết định ở trái; radar chiếm trục chính nửa dưới bên trái, có playback/time/legend; cột còn lại hourly, 10 days, marine, advisory, activity; hàng số đo dưới. Màu: sea/deep navy, turquoise, pearl white, solar gold, red cảnh báo có kiểm soát.

**Mobile:** 1 màn chính ưu tiên current + nhận định + hourly preview; bản đồ là view riêng toàn chiều ngang, timeline và legend đọc được; tab dưới dùng một tay. Trạng thái nắng/mưa/dông biểu diễn bằng atmospheric effect dịu, không lấy hiệu ứng làm bằng chứng thời tiết.

**Chi tiết bản đồ:** coastline thật, đảo lân cận, label Dương Đông/An Thới/Gành Dầu/Hòn Thơm có tọa độ kiểm chứng; vùng toàn đảo + 35 km; lớp màu 0.65-0.8 opacity tùy nền; nhãn vẫn nổi; zoom/recenter/locate/time range; chuyển layer không mất center/zoom; screen reader có nguồn và timestamp riêng.

**Thời gian:** play/pause, scrub, frame time; nếu nhiều timestamp khác nhau thì chọn từng nguồn riêng, không gộp một “LIVE” cho toàn bản đồ. Radar quan trắc chỉ lịch sử; mưa mô hình là tương lai. Cross-fade cho khung hình thực có cùng geo extent; không tạo future frames giả.

**Điểm trạm:** VVPQ chỉ sân bay; VRain hiển thị đúng vị trí nguồn; popup có `observed_at`, `value`, `unit`, loại tích lũy/cường độ, trạng thái QC và tuổi dữ liệu. Marker stale mờ hoặc unavailable rõ ràng.

## E. Lớp dữ liệu và quy tắc hiển thị

| Layer | Class | Nguyên tắc |
|---|---|---|
| Mưa radar | OBSERVED_RADAR | Chỉ raster georeferenced thật, kèm coverage mask/source time; không có => unavailable |
| Mây vệ tinh | OBSERVED_REMOTE | Himawari georeferenced, tách rõ ảnh mây và mưa mặt đất |
| Trạm mưa/sân bay | ACTUAL | Pins đúng điểm, QC + observed_at riêng, không suy cả đảo |
| Mưa dự báo | MODEL_ONLY | Lưới ECMWF 0.5 độ, tuyệt đối không gọi mưa hiện tại |
| Gió | MODEL_ONLY / ACTUAL_PIN | Particle chỉ dùng trường u/v hợp lệ; số đo trạm hiển thị pin riêng |
| Sóng | MODEL_ONLY | Lưới biển có hạn chế gần bờ; không dùng để suy diễn an toàn cano |
| Sét | UNAVAILABLE | Không dựng flash/pin giả trước khi có feed đo thực được xác nhận |

## F. Phương án đề xuất

**Phương án A - thực hiện trong giới hạn frontend-only:**
- Copy đúng thiết kế V5 sang một frontend branch/lab tách biệt.
- MapLibre basemap thật, labels, 35km, timeline, layer control, empty states, visual animation.
- Render những lớp có dữ liệu canonical đủ tốt; ví dụ điểm trạm ACTUAL, forecast grid, marine grid và cloud nếu đủ spatial coordinates/time.
- Radar mưa thật dùng lớp adapter đã định nghĩa, mặc định unavailable cho đến khi nguồn đạt đủ bằng chứng.

**Phương án B - bổ sung radar production khi đủ điều kiện (không nằm trong phạm vi kỹ thuật hiện tại):**
- Chốt 1 provider radar hợp pháp với coverage và sample Phú Quốc đã được kiểm chứng.
- Xác nhận tiles/time sequence, bit-depth/legend, tọa độ, freshness, SLA/usage và chi phí.
- Kết nối theo boundary Weather Engine/producer đã duyệt sau này; Core chỉ là canonical fact transport, không suy luận.

**Loại bỏ phương án C:** giả lập mưa/sét bằng noise/heatmap từ vài điểm hoặc ECMWF coarse để giả hình radar; nhúng ảnh tĩnh Windy/Naver/radar website như realtime; đọc GitHub raw hoặc Weather V3 legacy để vượt qua canonical.

## G. Acceptance / QA gates

1. **V5 Visual parity:** review screenshot/reference ở 1440x900, 1280x800, 390x844, 375x812 và landscape; không navigation trùng, clipping, rối chữ; mobile tap >=44px, motion reduced option.
2. **Data truth:** bản đồ mưa observed chỉ bật khi tile source+coverage+timestamp+rights pass; mây satellite không được gắn nhãn “radar”; forecast/model riêng; stale nói stale.
3. **Animation:** scrub trơn tru, play/pause hoạt động, không flash frame trắng, không giả thời gian tương lai, timestamp theo UTC+7 và source type.
4. **Map accuracy:** Phú Quốc/bờ đảo đúng, markers đúng tọa độ, 35km extents, vị trí An Thới/Hòn Thơm phù hợp; không centroid bịa.
5. **Performance:** đo iPhone Safari thật (không chỉ Chromium), Android và desktop; layer ảnh không gây memory leak, giữ frame budget thiết kế, tự hạ particle count khi mobile hoặc reduced motion.
6. **Security/Operations:** không gọi source cấm, không lộ key, no hot-loop/retry tile storm, cache và attribution đúng điều khoản. Không ghi trực tiếp Core/CMS.
7. **Release:** staging cô lập, ảnh và dữ liệu được xác minh, unit/browser QA, then explicit owner approval; không merge PR blocked thẳng main, không đổi route `/weather`.

## H. Tiêu chí GO cho radar thật

- [ ] Có bằng chứng radar provider phủ đúng vùng Phú Quốc ở những thời điểm kiểm chứng khác nhau
- [ ] Có quyền dùng công khai/commercial hoặc văn bản chấp thuận phù hợp
- [ ] Có dữ liệu ảnh georeferenced liên tiếp ít nhất vài frames và timestamps gốc
- [ ] Có color legend đúng biến: dBZ/rain intensity, không tráo nhiệt độ đỉnh mây thành mưa
- [ ] Có xử lý trường hợp không mưa, ngoài vùng phủ, stale, outages
- [ ] Có ngân sách request và kiểm thử mobile Safari thật
- [ ] Không thay đổi Engine/Core/production trong giai đoạn chỉ nghiên cứu frontend

**Kết luận:** V5 triển khai frontend rất khả thi. Phần bản đồ trạm, mô hình gió/sóng và cloud có nhiều dữ liệu sẵn. Radar mưa nhiều màu như mockup chỉ bảo đảm khi có nguồn ảnh radar thật phù hợp về địa lý, tuổi, chất lượng và quyền sử dụng. Không vì đạt visual mà đánh đổi tính đúng đắn.