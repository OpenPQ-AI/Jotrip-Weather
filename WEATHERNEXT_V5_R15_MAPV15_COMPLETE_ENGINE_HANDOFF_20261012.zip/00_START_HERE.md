# OPENPQ WeatherNext - Master V5 + deployed R15 + Map V15 | ENGINE HANDOFF
**Date:** 2026-10-12. **Status:** OWNER APPROVED VISUAL DIRECTION, INTEGRATION CANDIDATE ONLY, PRODUCTION HOLD.

## Priority and scope - READ THIS FIRST
**The owner had approved the COMPLETE WeatherNext layout BEFORE the map-only visual research.** This handoff consolidates:
1. **Visual Master V5** - approved page-wide visual design (11 October). THIS is the layout authority.
2. **R15 Integrated deployed reference** - the app actually served by https://weathernext.openphuquoc.com/?v=20261011-r15-integrated on 12 October, including its HTML, CSS, JS, hero and logo. This is a *dated snapshot for parity*, NOT proof of the immutable V5 design or permission to overwrite production. It exposes a v3.css/v3.js family despite the R15 query parameter.
3. **Map Visual V15** - separately approved detailed map UI on GitHub commit `ba26970ab9aff2e8451397a1640e6a9b0b256287`. Adopt ONLY the map renderer / five layers / timeline / map controls, preserving the page structure already approved.

**Never replace the whole WeatherNext page with the Map V15 fullscreen lab**. Do not reproduce the illustrative dashboard/card concept shown in another conversation, and do not restart visual design from scratch.

## Folder ordering
- `00_VISUAL_MASTER_V5_APPROVED/` - original V5 written design lock and chronology.
- `01_R15_DEPLOYED_SNAPSHOT/` - source of live R15 HTML/CSS/JS/hero/logo and SHA-256/UTC retrieval manifest (public frontend snapshot, not backend).
- `02_MAP_V15_APPROVED/` - V15 HTML, all six archived AHI satellite frames, archived marine fixture, Chrome screenshot evidence, README and QA manifest.
- `03_ENGINE_INTEGRATION/` - explicit component boundaries, data mapping, gates and copy/paste next-thread assignment.
- `04_SOURCE_REFS/` - immovable source commit, URLs and scope traceability.

## Visual authority: what stays
Desktop V5: ONE header, genuine Phu Quoc photographic hero, measured weather/current conditions and decision at left, map in the major main-area slot, hourly/10-day/marine/advisory/activity and measured detail panels retained. Deep navy/sea, turquoise, pearl white and selective sunshine/caution accents. No unexplained deletion, new card/dashboard redesign, duplicate navigation or top-level map-only replacement.
Mobile V5: current + decision + hourly preview first, full-width map as a separate rich view, thumb-friendly bottom navigation, no information stacking that hides weather. Map fullscreen immersive mode can be opened independently without losing current page.
Keep source/freshness, unit, source-classification and risk states from existing contracts.

## Critical interpretation
- `Mây`: OBSERVED_REMOTE Himawari satellite imagery. **NOT rain radar**.
- `Mưa`: **MODEL_FORECAST** ECMWF 0.5-degree sample. Never label `radar mưa trực tiếp`, and do not infer hourly intensity from unknown accumulation period.
- `Gió`: MODEL U/V. Particles/arrows must follow coordinates/time and meteorological U/V.
- `Sóng`: COPERNICUS_MARINE MODEL ~0.0833-degree archive; 1 confirmed frame at 2026-10-11 06:00Z. Current V15 wave replay is intentionally disabled; no invented frames or direction arrows before validated convention.
- `Nhiệt độ`: MODEL_FORECAST sampled archive, not a ground thermometer.
- Actual station rain and airport METAR use canonical point evidence/quality/time, not a model heatmap.
- Radar, if ever truly available, gets its own OBSERVED_RADAR layer with observed_at, geo coverage, licensing, color units. If missing: `Chưa có radar mưa được xác minh` not fake colored rainfall.
- All archived test assets are dated 11 October and **NOT live**.

## Execution gate
Implement ONLY in isolated WeatherNext branch and VPS-first staging (Cloudflare quota-safe). No writes to OpenPQ Core V1.2, weather/production, CMS, auth, DB, migrations, scheduler, ingestion, Cloudflare Worker route or domain DNS. Preserve other Labs independence.
First compare R15 runtime snapshot with V5 and check what parts already exist; don't blindly deploy snapshot files because they could be a different revision. Then make a scoped Map V15 adapter into V5 page, using existing canonical Weather Engine read-only interface.
QA with actual data / missing & stale source, desktop 1440×900 and mobile 390×844/375×812, pinch/zoom, land clip, overlay source labels, and **physical iPhone Safari**. Get owner acceptance of integrated screenshots before merge/deploy.

## Limit
**The original pixel-perfect V5 image itself was not recovered in this package.** Written V5 approved spec is present, and deployed R15 code/assets are included as the nearest running reference. Engine must not claim exact pixel parity without comparing to the owner's V5 image or obtaining that reference through original project files. This does not revoke the owner's approval of the previous design.

Handoff is complete as an **integration input**, not as a completed/production-released product.
