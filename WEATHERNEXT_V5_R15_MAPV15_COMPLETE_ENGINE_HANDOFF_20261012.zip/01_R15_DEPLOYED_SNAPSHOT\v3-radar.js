(()=>{
"use strict";
const DOM=id=>document.getElementById(id);
const S={expanded:false,map:null,target:null,field:null,layer:"cloud",data:null,satelliteMap:null,sstMap:null};
const ANCHORS={duong_dong:[10.215,103.96,"Dương Đông"],an_thoi:[10.035,104.02,"An Thới"],north:[10.36,103.91,"Bắc đảo"]};
const PLACES=[["Gành Dầu",10.376,103.9],["Cửa Cạn",10.29269,103.9148],["Dương Đông",10.2172,103.9593],["Hàm Ninh",10.18062,104.04463],["Bãi Sao",10.05726,104.03639],["An Thới",10.0191,104.015],["Bãi Thơm",10.41176,104.03105]];
const fmt=x=>Number.isFinite(x)?x.toLocaleString("vi-VN",{maximumFractionDigits:1}):"--";
const time=s=>new Intl.DateTimeFormat("vi-VN",{timeZone:"Asia/Ho_Chi_Minh",hour:"2-digit",minute:"2-digit"}).format(new Date(typeof s==="number"?s*1000:s));
const fresh=(s,m)=>{const a=Date.now()-Date.parse(s);return Number.isFinite(a)&&a>=-120000&&a<=m*60000};
const txt=(id,t)=>{if(DOM(id))DOM(id).textContent=t};
function base(el,zoom=9){const map=L.map(el,{zoomControl:false,scrollWheelZoom:false,attributionControl:true}).setView([10.2,104],zoom);
L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",{maxZoom:17,attribution:"Imagery © Esri"}).addTo(map);return map}
function expandMap(){
 S.expanded=!S.expanded;S.target.classList.toggle('radar-expanded',S.expanded);document.body.classList.toggle('radar-expanded-body',S.expanded);

 const b=DOM('radar-expand');if(b){b.textContent=S.expanded?'✕ Thu lại':'⛶ Mở rộng';b.setAttribute('aria-pressed',String(S.expanded))}setTimeout(()=>S.map?.invalidateSize(),80);
}
function mapTools(){
 const tools=L.control({position:'topleft'});tools.onAdd=()=>{const box=L.DomUtil.create('div','radar-map-tools');
 box.innerHTML='<button type="button" id="radar-expand" aria-pressed="false">⛶ Mở rộng</button><button type="button" id="radar-wide">Vùng rộng</button><label class="map-layer-select">Lớp <select id="map-layer-picker" aria-label="Chọn lớp bản đồ"><option value="observations">Trạm quan trắc</option><option value="cloud">Mây vệ tinh</option><option value="wind">Gió mô hình</option><option value="wave">Sóng mô hình</option><option value="temperature">Nhiệt độ mô hình</option><option value="air">Không khí mô hình</option></select></label>';
 L.DomEvent.disableClickPropagation(box);L.DomEvent.disableScrollPropagation(box);return box};tools.addTo(S.map);
 DOM('map-layer-picker').onchange=e=>{const b=document.querySelector('[data-layer="'+e.target.value+'"]');if(b&&!b.disabled)b.click();else e.target.value=S.layer};DOM('radar-expand').onclick=expandMap;DOM('radar-wide').onclick=()=>S.map.setView([10.2,104],7);
}
function mount(){
 const dest=DOM("mobile-radar-map");
 if(dest===S.target){S.map?.invalidateSize();return;}if(S.expanded)expandMap();if(S.map)S.map.remove();S.target=dest;S.map=base(dest,matchMedia("(min-width:751px)").matches?10:9);
 L.control.zoom({position:"bottomright"}).addTo(S.map);mapTools();
 const placeMarkers=PLACES.map(([name,lat,lon])=>[name,L.marker([lat,lon],{interactive:false,icon:L.divIcon({className:"",html:'<div class="weather-location-marker">'+name+"</div>",iconSize:[95,25],iconAnchor:[46,12]})}).addTo(S.map)]);
 const declutter=()=>placeMarkers.forEach(([name,marker])=>{const wide=S.map.getZoom()<9;marker.setOpacity(wide&&name!=="Dương Đông"?0:1);const label=marker.getElement()?.querySelector('.weather-location-marker');if(label)label.textContent=wide&&name==="Dương Đông"?"Phú Quốc":name});S.map.on('zoomend',declutter);declutter();
 const info=L.control({position:"bottomleft"});info.onAdd=()=>{const box=L.DomUtil.create("div","map-observation-key");box.id="map-visible-key";L.DomEvent.disableClickPropagation(box);return box};info.addTo(S.map);
 S.field=L.layerGroup().addTo(S.map);
 if(!S.satelliteMap&&DOM("satellite-mini-map"))S.satelliteMap=base(DOM("satellite-mini-map"),9);
 if(!S.sstMap&&DOM("sst-mini-map"))S.sstMap=base(DOM("sst-mini-map"),9);

 setTimeout(()=>{S.map?.invalidateSize();S.satelliteMap?.invalidateSize();S.sstMap?.invalidateSize();show()},150);
}
function palette(value,stops){let color=stops[0][1];for(const [threshold,c] of stops)if(value>=threshold)color=c;return color;}
function drawField(layer,key){
 const source=S.data?.openpq?.spatial?.[key==='wind'||key==='temperature'?'atmosphere':key==='wave'?'marine':'air'];
 if(!source||source.status!=='MODEL_REFERENCE'||!fresh(source.fetched_at,120))return 0;
 const variable={wind:'wind_speed_10m',temperature:'temperature_2m',wave:'wave_height',air:'european_aqi'}[key];
 const units={wind:' km/h',temperature:'°C',wave:' m',air:' EAQI'}[key];let count=0;
 const stops={wind:[[0,'#2385b3'],[10,'#3bbf9f'],[20,'#d5cc53'],[30,'#ec9256'],[45,'#d35468']],temperature:[[0,'#488cd5'],[25,'#46b8ad'],[28,'#c7ca63'],[30,'#eba252'],[33,'#da6652']],wave:[[0,'#3c9fba'],[.5,'#42bdad'],[1,'#d6ca64'],[1.5,'#ef9963'],[2.5,'#d7637a']],air:[[0,'#48b78c'],[40,'#b5cb60'],[60,'#e4bc50'],[80,'#e68a62'],[100,'#cb626d']]}[key];
 for(const c of source.cells||[]){
  if(!fresh(c.valid_at,180)||!Number.isFinite(c[variable])||!Number.isFinite(c.lat)||!Number.isFinite(c.lon))continue;
  const half=source.grid_deg/2;
  const shape=key==='air'?L.circleMarker([c.lat,c.lon],{radius:10,color:'#fff',weight:1,fillColor:palette(c[variable],stops),fillOpacity:.85}):L.rectangle([[c.lat-half,c.lon-half],[c.lat+half,c.lon+half]],{color:'#ffffff35',weight:.6,fillColor:palette(c[variable],stops),fillOpacity:.44});shape.bindTooltip(fmt(c[variable])+units+' · '+source.model+' · '+time(c.valid_at)+(key==='air'?' · CAMS gốc ~45 km':' · ô '+source.grid_deg+'°')).addTo(layer);
  if(key==='wind'&&Number.isFinite(c.wind_direction_10m))L.marker([c.lat,c.lon],{interactive:false,icon:L.divIcon({className:'',html:'<div class="grid-wind-arrow" style="transform:rotate('+((c.wind_direction_10m+180)%360)+'deg)">↑</div>',iconSize:[22,22],iconAnchor:[11,11]})}).addTo(layer);
  count++;
 }return count;
}
function drawCloud(layer,sat){
 if(!sat||sat.status!=="CURRENT"||!fresh(sat.sampled_time,40)||!Array.isArray(sat.cells))return 0;
 let count=0;
 sat.cells.forEach(([lat,lon,temp,height,fraction])=>{
  if(!Number.isFinite(temp)||!Number.isFinite(fraction)||fraction<=0)return;
  if(!Number.isFinite(lat)||!Number.isFinite(lon))return;
  const color=temp<=-65?"#a855f7":temp<=-40?"#228fe6":temp<=-15?"#57c8dd":"#d5e5ed";
  L.circleMarker([lat,lon],{radius:temp<=-40?15:11,color:color,weight:1,fillColor:color,fillOpacity:.25+.25*Math.min(1,fraction)}).bindTooltip("Đỉnh mây "+fmt(temp)+"°C · "+fmt(height/1000)+" km · điểm lấy mẫu từ ô ~0,15°").addTo(layer);count++;
 });return count;
}
let miniCloud=null,miniSea=null;
function minis(){
 if(!S.satelliteMap||!S.sstMap)return;
 miniCloud?.clearLayers();miniSea?.clearLayers();
 miniCloud=miniCloud||L.layerGroup().addTo(S.satelliteMap);miniSea=miniSea||L.layerGroup().addTo(S.sstMap);
 drawCloud(miniCloud,S.data?.openpq?.satellite);
 Object.entries(ANCHORS).forEach(([key,[lat,lon,name]])=>{
  const x=S.data?.openpq?.areas?.[key]?.sea_temperature;
  if(x?.status==="MODEL_REFERENCE"&&fresh(x.valid_at,180)&&fresh(x.fetched_at,480)&&Number.isFinite(x.sea_surface_temperature)){
   L.circleMarker([lat,lon],{radius:15,color:"#fff",weight:1,fillColor:x.sea_surface_temperature>=30?"#ef923b":"#12b6a0",fillOpacity:.9}).bindTooltip(name+" "+fmt(x.sea_surface_temperature)+"°C",{permanent:true,direction:"top"}).addTo(miniSea);
  }
 });
}
function show(){
 if(!S.map||!S.field)return;S.target.dataset.mapLayer=S.layer;S.field.clearLayers();
 document.querySelectorAll('[data-layer]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.layer===S.layer)));
 let title="";let legend="";
 if(S.layer==='observations'){
  title='Số đo tại trạm · chạm để xem thời điểm';
  legend='Chỉ hiển thị mẫu còn hạn tại vị trí trạm. Không suy ra vùng mưa toàn đảo từ các điểm đo.';
 }else if(S.layer==='cloud'){
  const sat=S.data?.openpq?.satellite,count=drawCloud(S.field,sat);title=sat?.status==="CURRENT"&&fresh(sat.sampled_time,40)?"Himawari "+time(sat.sampled_time)+(count?" · đỉnh mây, không phải lượng mưa":" · chưa có ô đỉnh mây đủ điều kiện"):"Đang cập nhật dữ liệu mây";
  legend="Màu là nhiệt độ đỉnh mây tại điểm lấy mẫu của ô ~0,15°. Khoảng giữa các điểm chưa được biểu diễn. Không phải lượng mưa hoặc vùng phủ radar.";
 }else{
  const dense=drawField(S.field,S.layer);
  const a=S.data?.openpq?.areas||{};let count=0;
  Object.entries(ANCHORS).forEach(([key,[lat,lon,name]])=>{
   const x=a[key];if(!x||dense)return;let value=null,valid=null;
   if(S.layer==="wind"&&x.availability==="REFERENCE_ONLY"&&fresh(x.updated_at,180)&&Number.isFinite(x.current?.wind_speed_10m)){value=fmt(x.current?.wind_speed_10m)+" km/h";valid=x.updated_at}
   if(S.layer==="wave"&&x.marine?.status==="MODEL_REFERENCE"&&fresh(x.marine.grid_valid_at,180)&&Number.isFinite(x.marine.wave_height_m)){value=fmt(x.marine.wave_height_m)+" m";valid=x.marine.grid_valid_at}
   if(S.layer==="temperature"&&x.availability==="REFERENCE_ONLY"&&fresh(x.updated_at,180)&&Number.isFinite(x.current?.temperature_2m)){value=fmt(x.current?.temperature_2m)+"°C";valid=x.updated_at}
   if(S.layer==="air"&&x.air_quality?.status==="MODEL_REFERENCE"&&fresh(x.air_quality.valid_at,180)&&fresh(x.air_quality.fetched_at,480)&&Number.isFinite(x.air_quality.european_aqi)){value=fmt(x.air_quality.european_aqi)+" EAQI";valid=x.air_quality.valid_at}
   if(!valid)return;
   const marker=L.marker([lat,lon],{icon:L.divIcon({className:"",html:'<div class="model-map-value">'+value+"</div>",iconSize:[100,36],iconAnchor:[50,18]})}).bindTooltip(name+" · ô mô hình "+time(valid));marker.addTo(S.field);count++;
  });
  const total=dense||count;
  legend=dense?(S.layer==='air'?"Điểm lấy mẫu API · CAMS gốc ~45 km. Không phải trường liên tục. ":"Ô mô hình gốc · không làm mịn hoặc tạo thêm độ chi tiết. ")+({wind:"Xanh: gió nhẹ · vàng/cam: mạnh hơn. Mũi tên chỉ chiều thổi.",temperature:"Xanh: mát · vàng/cam: nóng hơn.",wave:"Xanh: sóng thấp · vàng/cam: cao hơn.",air:"Xanh: EAQI thấp · vàng/cam: cao hơn."}[S.layer]):"Điểm mô hình tham khảo";
  title=total?({wind:"Gió",wave:"Sóng",temperature:"Nhiệt độ",air:"Không khí"}[S.layer])+" · "+total+(S.layer==='air'?" điểm mô hình":" ô mô hình"):"Lớp dữ liệu đang cập nhật";
 }
 const observations=S.data?.openpq?.observations;let stationCount=0;
 Object.values(observations?.vrain||{}).forEach(g=>{
  if((g.status!=='CURRENT'||!fresh(g.observed_at,90))&&Number.isFinite(g.lat)&&Number.isFinite(g.lon)&&S.layer==='observations'){L.circleMarker([g.lat,g.lon],{radius:9,color:'#94a3b8',weight:2,dashArray:'3 3',fillOpacity:0}).bindTooltip(g.source+' · quá hạn',{permanent:true,direction:'top',className:'station-stale-label'}).addTo(S.field);return;}
  if(g.status!=='CURRENT'||!fresh(g.observed_at,90)||!Number.isFinite(g.lat)||!Number.isFinite(g.lon)||!Number.isFinite(g.accumulation_mm)||g.accumulation_mm<0||Date.parse(g.period_end)<Date.parse(g.period_start))return;
  stationCount++;L.circleMarker([g.lat,g.lon],{radius:S.layer==='observations'?12:8,color:'#fff',weight:2,fillColor:'#8b5cf6',fillOpacity:1}).bindTooltip(g.source+' · '+fmt(g.accumulation_mm)+' mm tích luỹ · '+time(g.period_start)+' đến '+time(g.period_end)+' · chỉ tại trạm').addTo(S.field);
 });
 const syn=observations?.synop_48917,airport=observations?.airport_vvpq;
 [[syn,syn?.lat,syn?.lon,"Trạm Dương Đông",syn?.values?.air_temperature_c,240],[airport,airport?.lat,airport?.lon,"Sân bay Phú Quốc",airport?.temperature_c,75]].forEach(([obs,lat,lon,name,temp,age])=>{
  if(!obs||!Number.isFinite(lat)||!Number.isFinite(lon)||!fresh(obs.observed_at,age)||!Number.isFinite(temp)||(obs.station_id==='48917'&&obs.status!=='CURRENT'))return;
  stationCount++;L.circleMarker([lat,lon],{radius:S.layer==='observations'?10:7,color:"#ffffff",weight:3,fillColor:"#03c9c0",fillOpacity:1}).bindTooltip(name+" · "+fmt(temp)+"°C · "+time(obs.observed_at),{permanent:S.layer==='observations',direction:obs.station_id==='48917'?'left':'right',className:'station-current-label'}).addTo(S.field);
 });
 legend+=" Chấm tím: trạm mưa tích luỹ. Chấm xanh viền trắng: nhiệt độ quan trắc tại trạm, chạm để xem giờ đo.";
 const fieldSource=S.data?.openpq?.spatial?.[S.layer==='wind'||S.layer==='temperature'?'atmosphere':S.layer==='wave'?'marine':'air'];
 const stamp=S.layer==='cloud'?fresh(S.data?.openpq?.satellite?.sampled_time,40)?S.data.openpq.satellite.sampled_time:null:S.layer==='observations'?null:fieldSource?.cells?.find(c=>fresh(c.valid_at,180))?.valid_at;
 const displayTime=stamp?time(stamp):S.layer==='observations'?'Theo từng trạm':'Đang cập nhật';txt('hero-radar-time',displayTime);
 if(S.layer==='observations')title=stationCount?stationCount+' trạm có mẫu còn hạn · chạm xem giờ đo':'Chưa có mẫu quan trắc còn hạn';
 if(stamp&&S.layer!=='cloud')title+=' · '+displayTime;
 const picker=DOM('map-layer-picker');if(picker){picker.value=S.layer;picker.closest('.radar-map-tools').dataset.currentLayer=S.layer;for(const option of picker.options)option.disabled=!!document.querySelector('[data-layer="'+option.value+'"]')?.disabled;}
 const key=DOM('map-visible-key');
 if(key){key.replaceChildren();const heading=document.createElement('strong');heading.textContent=title;key.append(heading);
 const scales={cloud:[['#d5e5ed','> −15°C'],['#57c8dd','−40 đến −15'],['#228fe6','−65 đến −40'],['#a855f7','≤ −65°C']],observations:[['#03c9c0','Nhiệt độ đo'],['#8b5cf6','Mưa tích luỹ'],['#94a3b8','Mẫu quá hạn']],wind:[['#2385b3','<10'],['#3bbf9f','10–20'],['#d5cc53','20–30'],['#ec9256','30–45'],['#d35468','≥45 km/h']],wave:[['#3c9fba','<0,5'],['#42bdad','0,5–1'],['#d6ca64','1–1,5'],['#ef9963','1,5–2,5'],['#d7637a','≥2,5 m']],temperature:[['#488cd5','<25'],['#46b8ad','25–28'],['#c7ca63','28–30'],['#eba252','30–33'],['#da6652','≥33°C']],air:[['#48b78c','<40'],['#b5cb60','40–60'],['#e4bc50','60–80'],['#e68a62','80–100'],['#cb626d','≥100 EAQI']]};
 const scale=document.createElement('div');scale.className='map-color-scale';for(const [color,label]of scales[S.layer]||[]){const item=document.createElement('span'),swatch=document.createElement('i');swatch.style.background=color;item.append(swatch,document.createTextNode(label));scale.append(item)}key.append(scale);
 const details=document.createElement('details'),summary=document.createElement('summary');summary.textContent='Nguồn và giới hạn dữ liệu';const detail=document.createElement('p');detail.textContent=legend;details.append(summary,detail);key.append(details);
}
 txt('map-legend',legend);txt('radar-live-state',title);txt('radar-state',({cloud:'Mây vệ tinh',observations:'Trạm quan trắc',wind:'Gió dự báo',wave:'Sóng dự báo',temperature:'Nhiệt độ dự báo',air:'Không khí dự báo'}[S.layer]));
 txt('radar-msg',title+(S.layer==='observations'?'. Mưa là lượng tích luỹ trong kỳ đo, không phải mm/h.':S.layer==='cloud'?'. Đây là đỉnh mây được lấy mẫu, không phải lượng mưa.':'. Đây là dự báo ô lưới, không phải đo tại bãi hoặc tuyến cano.'));
}
function modelAvailable(key,d){
 const field=d?.openpq?.spatial?.[key==='wind'||key==='temperature'?'atmosphere':key==='wave'?'marine':'air'];
 const variable={wind:'wind_speed_10m',temperature:'temperature_2m',wave:'wave_height',air:'european_aqi'}[key];
 if(field?.status==='MODEL_REFERENCE'&&fresh(field.fetched_at,120)&&field.cells?.some(c=>fresh(c.valid_at,180)&&Number.isFinite(c[variable])&&Number.isFinite(c.lat)&&Number.isFinite(c.lon)))return true;
 return Object.values(d?.openpq?.areas||{}).some(a=>key==='wave'?a.marine?.status==='MODEL_REFERENCE'&&fresh(a.marine.grid_valid_at,180)&&Number.isFinite(a.marine.wave_height_m):key==='air'?a.air_quality?.status==='MODEL_REFERENCE'&&fresh(a.air_quality.valid_at,180)&&fresh(a.air_quality.fetched_at,480)&&Number.isFinite(a.air_quality.european_aqi):a.availability==='REFERENCE_ONLY'&&fresh(a.updated_at,180)&&Number.isFinite(a.current?.[variable]));
}
function apply(d){
 S.data=d;
 document.querySelectorAll('[data-layer]').forEach(b=>{
  const available=b.dataset.layer==='observations'?!!d?.openpq?.observations:b.dataset.layer==='cloud'?d?.openpq?.satellite?.status==='CURRENT'&&fresh(d.openpq.satellite.sampled_time,40)&&!!d.openpq.satellite.cells?.length:modelAvailable(b.dataset.layer,d);
  b.disabled=!available;b.setAttribute('aria-disabled',String(!available));
 });
 // A missing satellite field must not leave the initial map blank when stations exist.
 if(S.layer==='cloud'&&document.querySelector('[data-layer="cloud"]')?.disabled&&d?.openpq?.observations)S.layer='observations';
 show();minis();
}
function init(){
 if(!window.L){txt("radar-live-state","Bản đồ chưa tải được · vui lòng tải lại trang");DOM("mobile-radar-map").textContent="Bản đồ chưa tải được. Số đo từng trạm vẫn có trong mục Quan trắc.";return}
 document.querySelectorAll(".hero-radar-ui,.radar-tabs").forEach(group=>{
  ["wave","temperature","air"].forEach((key,i)=>{if(!group.querySelector('[data-layer="'+key+'"]')){const b=document.createElement("button");b.dataset.layer=key;b.textContent=["≋ Sóng","♨ Nhiệt độ","🍃 Không khí"][i];b.setAttribute("aria-pressed","false");group.insertBefore(b,group.querySelector(".radar-stamp"))}});
 });
 document.querySelectorAll("[data-layer]").forEach(b=>b.addEventListener("click",()=>{S.layer=b.dataset.layer;show()}));
 const legend=document.createElement('p');legend.id='map-legend';legend.className='map-legend';DOM('radar-msg').before(legend);
 mount();if(window.openpqDisplaySnapshot)apply(window.openpqDisplaySnapshot.data);window.addEventListener("resize",mount,{passive:true});
 window.addEventListener("openpq:render",ev=>apply(ev.detail.data));

}
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&S.expanded)expandMap()});
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
})();
