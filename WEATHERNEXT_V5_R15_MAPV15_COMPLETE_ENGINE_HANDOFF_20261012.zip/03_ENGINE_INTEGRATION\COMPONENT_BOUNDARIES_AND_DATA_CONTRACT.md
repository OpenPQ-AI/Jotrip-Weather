# WeatherNext Engine integration contract: MASTER V5 + R15 page + MAP V15
**Authority order:** V5 page design lock > verified R15 deployed page for practical parity > V15 map-only renderer. Data authority: **existing Weather Engine/CANONICAL contracts, never CSS mockups**.

## 1. Integration strategy
- Treat R15 snapshot `01_R15_DEPLOYED_SNAPSHOT` as READ-ONLY reference for the previously deployed UI, not an unconditional replacement or production artifact. All provided files are public frontend assets captured on 2026-10-12, so they may reference live endpoint URLs and are not a complete independent backend.
- Keep hero photography, current weather summary, feels-like, marine indicators, decision/advisory, hourly, 10-day, longrange, source-age badges, alerts, responsive layout and bottom navigation.
- Isolate Map V15 in a lazy-loaded map route/panel within WeatherNext. Remove V15 demo page header/footer/archive notice as appropriate for embedding, but preserve **per-layer timestamp, source, legend, gap/unavailable states**. Keep full-screen expand/collapse as part of map, but never turn all of WeatherNext into map-only.
- Avoid leaking Map V15 global CSS, `window.__ENGINE_SNAPSHOT`, fixture data, IDs or MapLibre render loop into R15 DOM. Namespace CSS + JS and export explicit `mountWeatherMap(host, adapter, options)`, `destroy()`; retain map center and selected layer when switching/reopening.
- Keep old weather map code only as a rollback reference until validated; no duplicate map canvases or double library-loading from R15 Leaflet + V15 MapLibre.
- Respect reduced motion and mobile CPU, retain coastline, correctly clipped water, source-specific playback frame timing. Attribution and data/licensing remain visible.

## 2. Canonical role inputs
Current WeatherNext candidate uses SAME-ORIGIN read-only `/weather/data/weather-runtime/{current,compact,forecast,marine,cloud,meta}.json`, with canonical receipt/reader and edge expiry validation. Engine verifies exact canonical source versions currently active before wiring anything. Do not bypass via GitHub RAW, demo fixtures, or the old standalone Weather V3 API.

- `current`: ground/VRain and airport context. Point-level measured value, observed_at, location, QC, accumulation interval, expiry; permit only pin rendering. Don't paint island-wide rain.
- `compact`: summary decisions per point; no invented observations.
- `forecast`: ECMWF frames `valid_time`, `run_time`, native grid bbox/cells, rain accumulation+unit/window, U/V component directions+units, temperature K/C; scan all cells for missing/out-of-range. Native 0.5 degree: display smoothing cannot create town-level certainty.
- `marine`: Copernicus Marine significant wave height, native grid coordinates/mask, explicit sample time, direction convention and period if confirmed. Prefer 0.0833° cells, strictly ocean-clipped; don't infer safe canoe operations from model color.
- `cloud`: satellite Himawari-9 VIS B02 / IR B13 with individually verified source time, georeferencing, parallax caveat, freshness, no future frame interpolation, correct attribution. VIS bright pixels need not mean clouds.
- `meta`: canonical transport health, source freshness / audience policy, no hidden stale fallback.

If a dataset is unavailable, use **UNKNOWN / UNAVAILABLE** with source/time; never replace with archived fixture or a synthetic map pretending to be real. Load source frame sets independently: cloud has six uneven archived times; wave archive only one; the ECMWF demo had seven 3h samples with unverified rain window.

## 3. Safety invariants
No fake radar, storm pins, rain animations, lightning, wave direction arrows, coastal safety conclusions or nowcasts unsupported by source. Model forecast is not real-time ground observation. Display observed/modeled classes per layer and per point. No fake radar intensities from `convective_score`. Source stale gets clear badge or field blank, not silent cached `LIVE`.
No publishing live weather sourced from the 2026-10-11 screenshots or fixtures. No changes to locked core or any production paths.

## 4. QA / acceptance
1. Screenshot compare full V5 page desktop/mobile with the original approved references. R15 live snapshot is not guaranteed a one-to-one V5 master rendering. Do not delete panels.
2. Map V15 cloud/rain/wind/wave/temp switch, animation, legend, zoom/pan/pinch, full-screen expand, no duplicate nav, no layout overflow.
3. Forecast samples match source at input coordinates/time, correct UTC->Asia/Ho_Chi_Minh conversion and units. Rain period must be explicitly verified before `mm/h`.
4. Wave OSM water mask has zero alpha on known land locations; no simulated direction with unknown convention. Missing marine source must show unavailable and single-frame replay disabled.
5. Fail/stale modes for each canonical role, CORS/timeouts, no key exposure, no retry storm, source receipts verified.
6. Physical iPhone Safari, Android, desktop performance and accessibility; no WebGL leaks, reduced-motion, screen reader source description and semantic controls.
7. Final integrated visual screenshot must be approved by user. **PRODUCTION HOLD** until separate release authorization and all gates pass.

## 5. Source provenance and reference
V5 written lock: `00_VISUAL_MASTER_V5_APPROVED/OPENPQ_WEATHERNEXT_V5_RADAR_VISUAL_RESEARCH_20261011.md`.
R15 deployed snapshot read on 2026-10-12: `01_R15_DEPLOYED_SNAPSHOT/SNAPSHOT_SOURCE_MANIFEST.txt`.
Map V15 immutable GitHub commit: `ba26970ab9aff2e8451397a1640e6a9b0b256287`, repo `kenzuko/Jotrip-Weather`, path `visual-lab/weathernext-map-v15`.
Original independent frontend candidate: `kenzuko/jotrip-home`, branch `feat/weather-next-independent-20261008`, path `weather-next/`; not guaranteed same deployed R15 page.
