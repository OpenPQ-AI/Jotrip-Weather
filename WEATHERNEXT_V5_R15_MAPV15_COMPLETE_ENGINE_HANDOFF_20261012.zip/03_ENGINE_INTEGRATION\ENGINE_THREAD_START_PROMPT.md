# Copy this entire prompt into the WeatherNext Engine thread

Tiếp tục WeatherNext từ ZIP MASTER V5 + R15 Integrated + Map V15, không khởi động lại.

**Thiết kế đã duyệt:** WeatherNext **Visual Master V5** là khóa giao diện tổng thể được duyệt ngày 11/10. **R15 Integrated** là mốc trang triển khai trước đây tại https://weathernext.openphuquoc.com/?v=20261011-r15-integrated, có mã snapshot frontend trong ZIP. Chỉ **Map Visual V15** là bổ sung cuối để thay khối bản đồ/radar chưa đạt. **Không xóa phần thông số, hero, cảnh báo, quan trắc, dự báo giờ, 10 ngày, marine, activity, top navigation hay bottom navigation. Không thiết kế lại trang chính theo ảnh mockup khác.**

ĐỌC ĐÚNG THỨ TỰ:
1. `00_START_HERE.md` - quyết định và quy tắc giữ nguyên
2. `00_VISUAL_MASTER_V5_APPROVED/OPENPQ_WEATHERNEXT_V5_RADAR_VISUAL_RESEARCH_20261011.md`
3. `01_R15_DEPLOYED_SNAPSHOT/` + `SNAPSHOT_SOURCE_MANIFEST.txt` - snapshot R15 đang phục vụ (read-only)
4. `02_MAP_V15_APPROVED/index.html` + `README.md` + `QA_MANIFEST.json` - map UI đã duyệt, 6 ảnh Himawari archive và 1 snapshot Sóng Copernicus archive
5. `03_ENGINE_INTEGRATION/COMPONENT_BOUNDARIES_AND_DATA_CONTRACT.md`

NHIỆM VỤ: giữ Visual Master V5 nguyên logic/bố cục/cảm xúc, so hiện trạng R15, trích Map V15 thành một component giới hạn phạm vi, kết nối read-only vào sáu canonical weather roles hiện có (current, compact, forecast, marine, cloud, meta); giữ nguồn, timestamp, QC, phân biệt thực đo/ảnh vệ tinh/mô hình dự báo. Phát lại theo từng nguồn thực, không nhầm mưa ECMWF với radar mặt đất. Nếu mất nguồn báo unavailable, không dùng fixture 11/10 như live.

Triển khai và kiểm thử trên isolated branch + VPS-first staging. Chưa merge/deploy weather hoặc weathernext production, chưa thay Cloudflare routes, Core V1.2, CMS, DB, auth, scheduler/ingest. QA Chrome desktop/mobile và **Safari iPhone thật**, chụp ảnh tổng V5 + map tích hợp để xin nghiệm thu trước bất kỳ release nào. Nếu thiếu hình Visual Master V5 pixel-perfect, nói rõ và tìm lại nguồn ảnh duyệt gốc; không bịa một master khác.

**Kết quả cần trả về:** nguồn trang R15 được dùng, file/component cụ thể được tích hợp, bảng 6 role dữ liệu và độ mới, ảnh render tổng mobile/desktop, tests/PASS-FAIL, lỗi còn thiếu và gate release. Không chỉ báo cáo tiến độ chung chung.
