# OPENPQ / WeatherNext - Map Visual Thread Handoff V8

**Ngày:** 11/10/2026 | **Múi giờ:** Asia/Ho_Chi_Minh | **Đích bàn giao:** LUỒNG VISUAL/FRONTEND MỚI

**Trạng thái:** FRONTEND PROTOTYPE - visual chưa đạt, chưa nghiệm thu, chưa bàn giao Engine, chưa merge, chưa deploy lên production.

## A. Mục tiêu và khóa đã được người dùng chốt

Mục tiêu duy nhất của công việc này là **màn quan trắc/bản đồ thời tiết Phú Quốc kiểu Windy, dễ nhìn và sống động**, không phải làm trang dashboard nhiều card. Bản đồ gần như fullscreen ở cả desktop và iPhone, trên đó các lớp **Mây vệ tinh, Mưa dự báo, Gió, Sóng, Nhiệt độ** hoạt động. Chạm vào bản đồ/điểm trạm để biết tình hình, có thanh thời gian phát lại. Thiết kế có cá tính Phú Quốc, không chỉ bắt chước giao diện Windy.

Người dùng đã duyệt hướng **Map Master** và muốn chất lượng visual sát concept minh họa `references/WINDY_STYLE_MAP_MASTER_TARGET_CONCEPT.png`. Nhưng dữ liệu và địa lý trong hình AI có thể sai. Chỉ lấy nó làm **chuẩn bố cục, cảm xúc, phân cấp thông tin, màu sắc, nhịp chuyển động**; mọi địa lý và tín hiệu khí tượng ở sản phẩm phải tuân theo dữ liệu thật.

**Khóa phạm vi tuyệt đối:** chỉ visual/frontend/prototype cô lập. Không sửa các nguồn dữ liệu, thuật toán forecast, scheduler, ingest, API, DB, CMS, auth, Core V1.2, Cloudflare production. Tuân thủ VPS-FIRST và quota-safe. Không gửi sang Engine tích hợp khi visual chưa được chính người dùng duyệt. Không tự ý merge hoặc deploy `weather`/`weathernext` production.

## B. Vì sao các bản trước vẫn chưa đạt

Mạch nghiên cứu đã đi qua rất nhiều phiên bản và người dùng đã nhiều lần phản hồi "chưa đạt":

| Vòng | Đã thử | Phản biện thực tế |
|---|---|---|
| Trang WeatherNext V2-V5 | Hero bầu trời, dự báo giờ/10 ngày, radar card, giao diện du lịch | V5 chốt hướng trang chính; **phần bản đồ riêng** mới là điểm cần xử lý; không làm lại trang tổng. |
| Engine Map V1 | Raster trường mưa ECMWF, gió vector, timeline, điểm trên bản đồ | Lưới mưa 0,5° quá thô để tạo các cụm mưa kiểu radar; nền bản đồ rất sơ lược. |
| Cloud Visual V2 | Mây Himawari dạng số liệu lưới, tách quan trắc và dự báo | Nhiều vùng màu vuông, mây như khối nhiệt; chưa có texture ảnh vệ tinh. |
| Map Master V4 | Menu Windy, timeline/zoom, 5 lớp, mobile | Kiểu bản đồ đồ chơi; rìa cloud ô vuông; nhiều panel che đảo. |
| Map Master V5 | Sử dụng đủ 1.064 ô x 6 khung mây; điểm VRain; renderer Canvas | Chỉ số nhiệt độ đỉnh mây vẫn không tạo được texture thật; basemap chưa đủ chi tiết. |
| V6 / V6.1 | Đổ sáng/đổ bóng, rìa dữ liệu theo confidence, menu mobile tinh gọn | Cải thiện ít; vùng mây vẫn cứng; fallback coast quá giản lược. |
| V7 | MapLibre GL + vector tiles VersaTiles; frontend cô lập, có fallback | Đã kiểm thử logic offline, nhưng **không xác nhận đủ end-to-end khi tile vector thực sự render trên Safari**. Tạo HTTPS preview Vercel bị 403 quyền. |
| **V8 (gói này)** | Tinh chỉnh bão hòa/màu mây, độ alpha, overlay, nền dự phòng và contrast; noindex cho HTML | **Chưa đạt chuẩn Windy**, bản render OFFLINE còn giống silhouette đảo + lớp màu mờ. Cần đi vào đúng nguyên nhân, không thêm UI chrome. |

**Kết luận nghiên cứu có tính quyết định:** với dữ liệu mưa ECMWF 0,5° (và mây Himawari lấy mẫu ra lưới 0,075°), không thể trung thực vẽ ra "radar mưa nhiều đốm sắc nét" giống một ảnh minh họa AI. Hãy khai thác tối đa visual nền vector thật, vân mây ảnh vệ tinh khi có nguồn được phép, hạt gió đúng vector U/V, lớp màu dự báo đúng độ phân giải, chú giải nguồn/thời gian. Không ngụy tạo chi tiết bằng noise hoặc hiệu ứng giả mưa.

## C. Tài sản đang có trong gói

- `frontend/V8/index.html`: một file HTML độc lập (~59 KB), gồm HTML/CSS/JS inline và fixture dự báo/mây ngày 11/10/2026; **các thư viện/tile map online vẫn cần kết nối mạng**. Có offline fallback.
- `history/V7/index.html`: mốc code trước V8 để diff, không phải code thay thế tốt hơn.
- `references/WINDY_STYLE_MAP_MASTER_TARGET_CONCEPT.png`: hình được dùng để chốt ý tưởng. Concept AI, không thể dùng làm lớp thời tiết hoặc nền địa lý live.
- `screenshots/V8_OFFLINE_MOBILE_390.png`, `V8_OFFLINE_MOBILE_360.png`, `V8_OFFLINE_DESKTOP_1440.png`: ảnh Playwright Chromium chụp từ code hiện hành (chế độ chặn mạng), **không phải ảnh chuẩn đã duyệt**.
- `scripts/test_v8_offline.py`: script thử frontend offline; yêu cầu Python Playwright và Chromium cài sẵn. Không xác minh map online.
- `docs/02_QA_GATES.md`: check từng điều kiện nghiệm thu.
- `docs/03_DATA_AND_RENDER_CONTRACT.md`: nguồn và quy tắc hiển thị dữ liệu.
- `docs/04_NEW_THREAD_PROMPT.md`: prompt mới, viết sẵn để chuyển.

### Mã nguồn GitHub

Bản V7 được đưa lên **nhánh độc lập**, không đụng `main`:

- Repo: `kenzuko/Jotrip-Weather`
- Branch: `feat/weathernext-map-v7-visual-preview-20261011`
- Path: `visual-lab/weathernext-map-v7/index.html`
- Commit ghi nhận: `ff4b9a3247134a638a285638af414eaac25cc7cf`
- **V8 trong ZIP là phiên bản local**, không được tuyên bố đã push GitHub.

Không dùng URL GitHub **xem source** như URL preview interactive. Trước đó người dùng nhấn HTML ở ChatGPT iPhone và không mở được. Hướng xem đúng là HTTPS preview độc lập được kiểm chứng bằng iPhone Safari, chỉ làm sau khi giải quyết visual/hosting an toàn.

## D. Dữ liệu đã xác minh trong nghiên cứu

### Dữ liệu mây thực quan trắc

- Repo nguồn: `kenzuko/Jotrip-Weather/data/weather-runtime/cloud.json`.
- Nguồn: JMA Himawari-9 via NOAA Open Data; lớp trong nghiên cứu là AHI cloud-top derived fields, không phải radar mặt đất.
- Snapshot 11/10/2026: 6 frames với 1.064 cells/frame; lưới hiển thị 0,075°; các mốc có khoảng thời gian KHÔNG đều.
- Các field ở pipeline có `cloud_top_median_c`, `cloud_top_cold_c`, `cloud_top_high_m`, `convective_score`, tọa độ, thời gian. Fixture frontend dùng biểu diễn nén của một số trường; thiếu texture ảnh vệ tinh AHI gốc.
- Không được dùng `convective_score` để tự quyết rằng nơi đó đang mưa hoặc có sét; nếu không đủ dữ liệu phải ghi "chưa rõ".

### Dữ liệu mô hình dự báo

- `data/weather-runtime/forecast.json` trong repo: ECMWF Open Data normalized by JoTrip Weather, 0,5° ở snapshot nghiên cứu, chứa mưa dự báo và vector U/V trong các khung giờ (một số frame không đủ cell, cần validation trước khi dùng).
- `data/weather-runtime/marine.json`: sóng Copernicus Marine trong nghiên cứu, ô lưới wave có độ phân giải danh định khoảng 0,0833°; cần lấy trường sóng tương ứng từng frame thực nếu thay sample.
- `data/weather-runtime/current.json`: có VRain thực đo tại An Thới, Cửa Cạn, Bãi Thơm và quan trắc sân bay VVPQ trong hệ nguồn; trạm có chất lượng và độ mới khác nhau. Trạm không được thay thế bằng màu "mưa khắp đảo".
- Frontend mẫu **không tự cập nhật**, không chứng minh sản phẩm WeatherNext live hiện ổn hay nguồn ngày hôm nay đúng.

Chi tiết và những trường chưa xác minh: xem `docs/03_DATA_AND_RENDER_CONTRACT.md`.

## E. Các rào cản phải tiếp tục giải quyết, theo thứ tự

**P0 - Bản đồ nền thật, đúng Phú Quốc, có thể nhìn thấy.** Chạy một lần map-only qua HTTPS hoặc local dev server có mạng đáng tin cậy. Dùng MapLibre + vector tiles, có đường bờ/đảo nhỏ/đường sá/địa danh đúng. Không dựng nền rừng/độ cao giả, không lấy ảnh AI làm nguồn geo. Thử trực tiếp iPhone Safari. Chỉ sau khi chứng minh ảnh nền mới overlay thời tiết.

**P0 - Mây thực có chiều sâu nhưng trung thực.** Mây dựa trên Himawari thực, giữ vùng dữ liệu missing/uncertain; nếu chỉ có field cloud-top thì diễn đạt là "mây đỉnh lạnh / tín hiệu vệ tinh". Cần ảnh AHI georeferenced/texture thật được cấp phép nếu muốn gần hình Windy, hoặc chấp nhận hiển thị cloud-top map kiểu infrared mà không tạo texture giả. Không hòa lẫn với radar mưa quan trắc.

**P0 - Trường mưa và gió dễ hiểu.** Mưa ECMWF 0,5° phải tự nhiên về màu (raster smooth có giới hạn), chú giải `mm/3 giờ` hoặc định nghĩa đúng theo dữ liệu, không vẽ đốm mưa nhỏ để lừa độ phân giải. Particle dùng U/V, tính lại theo phép chiếu bản đồ khi pan/zoom, không phải dòng hạt ngẫu nhiên.

**P1 - Mobile-first.** Mở lên thấy ngay đảo và vùng biển, lớp ở rìa phải gọn, timeline nằm sát cuối màn hình, legend rõ ràng không đè lên thông tin quan trọng; bấm lớp, kéo timeline, đóng pop-up, pan/pinch/zoom mượt. Giữ người dùng luôn biết đang xem "Quan trắc" hay "Dự báo".

**P1 - QA nghiêm túc và xem được.** Đưa ảnh thật từ browser gồm cloud, rain, wind ở desktop và iPhone. Test cả mạng bình thường, mạng yếu/mất mạng, CORS, phiên bản Safari iPhone, mất frame/stale; kiểm tra fail-safe. Sau đó mới xin người dùng chốt. Không dùng điểm chấm thẩm mỹ tự suy đoán làm tiêu chí đạt.

## F. Hạn chế đặc biệt của V8 cần biết trước khi sửa

1. Code độc lập chứa cả CSS/JS/dữ liệu archive inline. Sửa regex trong file rất dễ hỏng; nên tách module frontend theo môi trường thử V9, nhưng **không chạm Engine**.
2. Nền fallback silhouette hiện không được chứng minh là đường bờ GIS đủ chuẩn để công bố. **Không coi nó là "bản đồ Phú Quốc chính xác"**.
3. Khi thiếu tile, vẫn nhìn thấy fallback - đây là thiết kế fail-safe, nhưng không phải điểm chất lượng visual chính.
4. Bản V8 CSS giảm opacity mây để nền dễ đọc hơn nhưng không thể tạo ảnh vệ tinh gốc chỉ từ cloud-top số liệu.
5. Hai dòng thời gian hoàn toàn khác nhau: quan trắc Himawari (6 khung không đều) và dự báo ECMWF (nhiều khung cách giờ). Không phát liên tục như thể mọi frame có cùng khoảng thời gian nếu UX ngụ ý tốc độ quan trắc thực.
6. Popup trạm VRain: phải ghi tích lũy kỳ đo và trạng thái hết hạn, không mô tả thành lượng mưa giờ thực nếu nguồn không cung cấp cường độ.
7. Tham chiếu ảnh chuẩn có các con số, bão mưa và hình dạng đảo được AI tự dựng. Không dùng để so tính đúng khí tượng.

## G. Nghiệp vụ quyền và vận hành

- Chỉ Visual/Frontend, không thay đổi backend, CMS, identity, key/token, DB, scheduler, core production, Cloudflare Worker route hoặc project weather đang chạy.
- User muốn VPS-FIRST và tránh làm test lặp đi lặp lại trên Cloudflare production. Thử isolated VPS/Windows hoặc local trước.
- Việc tạo preview Vercel trên team `jotrip-lab` từng bị **403 Forbidden**; CLI Vercel không có phiên đăng nhập phù hợp trên Mac mini tại lần thử. **Chưa có URL preview HTTPS xác nhận.** Không giả lập link.
- Mac mini từng tải được một số endpoint CDN/style/tile, nhưng một số khác bị timeout; việc `curl` trả 200 không chứng minh `MapLibre` render end-to-end với tile, font, glyph và WebGL.
- Không làm việc trên máy tính người dùng khi không cần; ưu tiên máy Windows PHUQUOCLUX nếu có permission và năng lực. Không xóa UniKey hoặc bất cứ tệp/app/thư mục có tên PhuQuocLux.
- Chỉ chuyển sang Engine sau khi người dùng phê duyệt visual trên bản render **thực**; luồng Engine lúc đó nhận data contract, không nhận nhiệm vụ thiết kế lại.

## H. Luồng mới cần báo gì cho người dùng

- Đầu tiên mở ảnh mục tiêu + ảnh V8 offline, nhận vấn đề thật sự.
- Nghiên cứu/triển khai một bản V9 bản đồ vector + cloud/rain/wind; không thêm menu/card; xuất ảnh và video 10-15 giây (nếu thực sự tạo được) ở iPhone và desktop; thử offline và online.
- Trả lời minh bạch: điểm nào đạt, điểm nào chưa, trường nào source từ engine, trường nào thiếu source.
- Không tự tuyên bố hoàn thành hoặc hứa "làm 100% Windy" nếu chưa có bằng chứng từ dữ liệu và iPhone Safari.

**Kết luận khóa:** V8 là checkpoint nghiên cứu chuyển luồng. Chưa được nghiệm thu. V9 phải tập trung chất lượng **nền bản đồ thật + lớp mây IR/texture hợp lệ + mưa/gió dễ đọc**. Khi đạt mới gửi handoff cho Engine.