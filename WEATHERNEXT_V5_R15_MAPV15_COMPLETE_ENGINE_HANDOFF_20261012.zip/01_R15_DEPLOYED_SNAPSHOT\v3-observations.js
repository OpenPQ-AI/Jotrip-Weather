(()=>{
'use strict';
const $=id=>document.getElementById(id),fmt=x=>Number.isFinite(x)?x.toLocaleString('vi-VN',{maximumFractionDigits:1}):'--';
const fresh=(s,limit)=>{const age=Date.now()-Date.parse(s);return Number.isFinite(age)&&age>=-120000&&age<=limit*60000};
const time=s=>Number.isFinite(Date.parse(s))?new Intl.DateTimeFormat('vi-VN',{timeZone:'Asia/Ho_Chi_Minh',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(s)):'Chưa có giờ đo';
function render(d){
 const root=$('observation-cards');root.replaceChildren();const op=d?.openpq,obs=op?.observations||{};
 const airport=obs.airport_vvpq,syn=obs.synop_48917;
 const rows=[['Sân bay Phú Quốc',airport,fresh(airport?.observed_at,75)&&airport?.station_id==='VVPQ'&&Number.isFinite(airport?.temperature_c),airport?.temperature_c,'°C'],['Trạm Dương Đông',syn,syn?.status==='CURRENT'&&fresh(syn?.observed_at,240)&&Number.isFinite(syn?.values?.air_temperature_c),syn?.values?.air_temperature_c,'°C']];
 for(const [key,name] of [['an_thoi','An Thới'],['cua_can','Cửa Cạn'],['bai_thom','Bãi Thơm']]){
  const g=obs.vrain?.[key],valid=g?.status==='CURRENT'&&fresh(g.observed_at,90)&&Number.isFinite(g.accumulation_mm)&&g.accumulation_mm>=0&&Number.isFinite(Date.parse(g.period_start))&&Date.parse(g.period_end)>=Date.parse(g.period_start);
  rows.push(['Trạm mưa '+name,g,valid,g?.accumulation_mm,'mm tích luỹ']);
 }
 for(const [name,x,valid,value,unit] of rows){
  const card=document.createElement('article');card.className='observation-card';card.dataset.fresh=String(!!valid);
  const title=document.createElement('b');title.textContent=name;
  const metric=document.createElement('strong');metric.textContent=valid?fmt(value)+' '+unit:'Đang cập nhật';
  const timestamp=document.createElement('small');timestamp.textContent=(valid?(unit.startsWith('mm')?'Mốc mẫu: ':'Đo lúc '):'Mẫu gần nhất: ')+time(x?.observed_at);
  const note=document.createElement('p');note.textContent=valid&&unit.startsWith('mm')?'Kỳ nguồn công bố: '+time(x.period_start)+' đến '+time(x.period_end):valid?'Số đo chỉ đại diện tại trạm.':'Không dùng số đo quá hạn hoặc chưa kiểm chứng.';
  card.append(title,metric,timestamp,note);root.append(card);
 }
 let evidence=$('verification-progress');if(!evidence){evidence=document.createElement('p');evidence.id='verification-progress';$('methods').querySelector('.method-body').append(evidence)}
 const v=op?.verification;evidence.textContent=d?'Kiểm chứng: '+(v?.forecast_snapshots??'đang đếm')+' bản dự báo lưu trước sự kiện · '+(v?.station_observations??'đang đếm')+' mẫu quan trắc · '+(v?.gauge_observations??'đang đếm')+' mẫu trạm mưa. Chưa công bố độ chính xác; sét trực tiếp chưa kết nối, radar tạm ngừng.':'Kiểm chứng đang cập nhật. Chưa công bố độ chính xác dự báo.';
 const score=v?.temperature_diagnostics;if(d&&score)evidence.textContent+=' Đối chiếu nhiệt độ với trạm 48917: '+score.matched_cases+' cặp trên '+score.independent_utc_days+' ngày UTC; cần ít nhất 30 cặp và 7 ngày để hiển thị chỉ số tham khảo. Mưa và sóng chưa có đánh giá độ chính xác.';
 if(score?.status==='POINT_TEMPERATURE_DIAGNOSTICS'&&Number.isFinite(score.model_mae_c)&&Number.isFinite(score.persistence_mae_c))evidence.textContent+=' Sai số tuyệt đối trung bình tại trạm tham chiếu: mô hình '+fmt(score.model_mae_c)+'°C; giữ số đo trước đó '+fmt(score.persistence_mae_c)+'°C. Không đại diện toàn đảo.';
}
document.querySelectorAll('.decision-option,.nav-links a[href="#radar"]').forEach(a=>a.addEventListener('click',e=>{if(a.getAttribute('href')!=='#radar')return;e.preventDefault();document.getElementById('radar').scrollIntoView({behavior:'smooth',block:'center'})}));
const compare=document.querySelector('.compare-row');if(compare)$('season').append(compare);
window.addEventListener('openpq:render',e=>render(e.detail.data));if(window.openpqDisplaySnapshot)render(window.openpqDisplaySnapshot.data);else render(null);
})();
