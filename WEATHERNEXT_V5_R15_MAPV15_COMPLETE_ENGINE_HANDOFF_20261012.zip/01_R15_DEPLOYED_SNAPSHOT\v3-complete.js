(()=>{"use strict";
let snapshot=null,region="duong_dong";const $=id=>document.getElementById(id);
const fmt=(x,d=0)=>typeof x==="number"&&Number.isFinite(x)?x.toLocaleString("vi-VN",{maximumFractionDigits:d}):"--";
const time=s=>Number.isFinite(Date.parse(s))?new Intl.DateTimeFormat("vi-VN",{timeZone:"Asia/Ho_Chi_Minh",hour:"2-digit",minute:"2-digit"}).format(new Date(s)):"chưa có giờ hợp lệ";
const fresh=(s,min)=>{const a=Date.now()-Date.parse(s);return Number.isFinite(a)&&a>=-120000&&a<=min*60000};
function clearSupplemental(){
 ['satellite-detail','season-description','season-baseline','future-detail','sst-note'].forEach(id=>{if($(id))$(id).textContent='Nguồn đang cập nhật; chưa có dữ liệu đủ điều kiện.'});
 $('climate-months')?.replaceChildren();if($('ensemble-detail'))$('ensemble-detail').textContent='';
 document.querySelectorAll('.compare-item small').forEach(x=>x.textContent='Đang cập nhật');
}
function render(){
 const a=snapshot?.openpq?.areas?.[region]||{},op=snapshot?.openpq;
 if($("area-picker"))$("area-picker").value=region;
 if(!op){clearSupplemental();if($("station-line"))$("station-line").textContent="Quan trắc đang cập nhật";if($("satellite-status"))$("satellite-status").textContent="Đang cập nhật";if($("satellite-detail"))$("satellite-detail").textContent="";["indicator-uv","indicator-aqi","indicator-pressure","indicator-visibility","sst-value"].forEach(id=>{if($(id))$(id).textContent="--"});return}
 const ind=a.indicators||{},aq=a.air_quality||{},sst=a.sea_temperature||{};
 const good=x=>x.status==="MODEL_REFERENCE"&&fresh(x.valid_at,180)&&fresh(x.fetched_at,480);
 const val=(id,v,suffix="")=>{if($(id))$(id).textContent=fmt(v,1)+(typeof v==="number"?suffix:"")};
 val("indicator-uv",good(ind)?ind.uv_index:null,"");
 val("indicator-aqi",good(aq)?aq.european_aqi:null," EAQI");
 val("indicator-pressure",good(ind)?ind.pressure_msl:null," hPa");
 val("indicator-visibility",good(ind)?ind.visibility/1000:null," km");
 val("sst-value",good(sst)?sst.sea_surface_temperature:null,"°C");
 if(good(ind)){
  $("metric-humidity").textContent=fmt(ind.relative_humidity_2m)+"%";
  if(typeof ind.visibility==="number")$("metric-visibility").textContent=fmt(ind.visibility/1000,1)+" km";
 }
 const labels=document.querySelectorAll('.hero-metrics>div>span');
 labels[0].textContent='Mưa mô hình · '+(a.availability==='REFERENCE_ONLY'&&fresh(a.updated_at,180)?time(a.updated_at):'đang cập nhật');
 labels[1].textContent='Độ ẩm mô hình';labels[2].textContent='Gió mô hình';labels[3].textContent='Tầm nhìn mô hình';
 const syn=region==="duong_dong"?op.observations?.synop_48917:null;
 if(syn?.status==="CURRENT"&&fresh(syn.observed_at,240)&&typeof syn.values?.air_temperature_c==="number"){
  const t=syn.values.air_temperature_c,dew=syn.values.dewpoint_c;
  $("hero-temp").textContent=fmt(t)+"°";
  labels[1].textContent='Độ ẩm trạm* · '+time(syn.observed_at);
  labels[2].textContent='Gió trạm · '+time(syn.observed_at);
  $("hero-summary").textContent="Quan trắc tại trạm Dương Đông";
  $("hero-updated").textContent="Trạm Dương Đông · "+time(syn.observed_at)+" · "+new Intl.DateTimeFormat("vi-VN",{timeZone:"Asia/Ho_Chi_Minh",day:"2-digit",month:"2-digit"}).format(new Date(syn.observed_at));
  $("hero-desc").textContent="Dự báo bên dưới có thể khác số đo tại trạm.";
  if(typeof dew!=="number")$("metric-humidity").textContent="--";
  if(typeof dew==="number")$("metric-humidity").textContent=fmt(100*Math.exp(17.625*dew/(243.04+dew)-17.625*t/(243.04+t)))+"%*";
  $("metric-wind").textContent=fmt(syn.values.wind?.speed_kmh,1)+" km/h";
  $("hero-symbol").textContent="🌡";
  $("hero-why").textContent="Số đo tại trạm Dương Đông. Mưa là dự báo ô lưới; độ ẩm * tính từ nhiệt độ và điểm sương.";
  $("quick-verdict").textContent="Theo dõi mưa theo giờ";
 }
 const daily=op.ensemble_status?.status==='MODEL_REFERENCE'&&fresh(op.ensemble_status.fetched_at,480)?a.ensemble_days||[]:[];
 document.querySelectorAll(".day-tile").forEach(tile=>{
  const d=daily.find(x=>x.date===tile.dataset.day);
  if(d){tile.querySelector("em").textContent=d.complete_day?fmt(d.rain_ge_1mm_probability)+"% mưa ≥1 mm":"Thiếu giờ trong ngày";tile.classList.toggle('partial-day',!d.complete_day);tile.classList.toggle('partial-ensemble-day',!d.complete_day);tile.title=d.members+" thành viên GEFS; "+(d.complete_day?"xác suất tổng mưa ngày ≥1 mm":"chỉ bao phủ một phần ngày, không công bố xác suất cả ngày")+"; "+d.coverage_hours+" giờ";}
  const local=a.days?.find(x=>x.date===tile.dataset.day);
  if(local&&local.coverage_hours!==24){tile.classList.add('partial-day');if(!tile.querySelector('.low').textContent.includes('IFS'))tile.querySelector('.low').textContent+=' · IFS '+local.coverage_hours+'/24h';tile.title+='; IFS chỉ có '+local.coverage_hours+'/24 giờ';}
 });
 const selected=document.querySelector('.day-tile[aria-pressed=true]');
 const ed=daily.find(x=>x.date===selected?.dataset.day),md=a.days?.find(x=>x.date===selected?.dataset.day);
 let uncertainty=$('ensemble-detail');
 if(!uncertainty){uncertainty=document.createElement('div');uncertainty.id='ensemble-detail';uncertainty.className='ensemble-detail';$('selected-day-detail').append(uncertainty)}
 uncertainty.textContent=ed?('ECMWF IFS: '+fmt(md?.rain_mm,1)+' mm ('+md?.coverage_hours+' giờ) · GEFS: trung vị '+fmt(ed.rain_p50_mm,1)+' mm ('+ed.coverage_hours+' giờ), phân vị 90% '+fmt(ed.rain_p90_mm,1)+' mm. '+(ed.complete_day?'Xác suất mưa ≥1 mm: '+ed.rain_ge_1mm_probability+'%.':'GEFS thiếu giờ, không công bố xác suất cả ngày.')+' Hai mô hình có thể khác nhau; chưa hiệu chỉnh bằng quan trắc địa phương.'):'';
 $('ten-note').textContent='Nhiệt độ và biểu tượng: ECMWF IFS. '+(daily.length?'Xác suất mưa: '+op.ensemble_status.members+' thành viên GEFS, tổng ngày ≥1 mm. Ngày thiếu giờ được ghi riêng.':'GEFS đang cập nhật; lượng mưa trên thẻ là dự báo IFS, không phải xác suất.')+' Chạm một ngày để xem chi tiết.';
 const airport=op.observations?.airport_vvpq;
 $("station-line").textContent=airport&&fresh(airport.observed_at,75)?"Sân bay Phú Quốc · "+fmt(airport.temperature_c)+"°C · "+time(airport.observed_at)+" · chỉ tại sân bay":"Sân bay Phú Quốc đang cập nhật";
 const health=op.source_health||{};const count=Object.keys(health).length;
 $("source-health").querySelector("summary span").textContent=count+" mục nguồn · Xem thời điểm";
 for(const [k,h] of Object.entries(health)){
  if(document.querySelector('[data-source="'+k+'"]'))continue;
  const row=document.createElement("div");row.className="source-health-row";row.dataset.source=k;row.dataset.status=h.status;
  const b=document.createElement("b");b.textContent=h.source;
  const s=document.createElement("small");s.textContent=(h.status==="MODEL_REFERENCE"?"Dự báo tham khảo":h.status==="REANALYSIS_REFERENCE"?"Tái phân tích lịch sử":"Đang cập nhật")+(h.source_time?" · kiểm tra "+time(h.source_time):"");row.append(b,s);$("source-health-grid").append(row);
 }
 const climate=op.climate;
 if(climate?.months?.length===12){
  const month=Number(new Intl.DateTimeFormat("en",{timeZone:"Asia/Ho_Chi_Minh",month:"numeric"}).format(new Date()));
  const m=climate.months.find(x=>x.month===month);
  $("season-description").textContent="Tháng "+month+" thường có "+m.mean_rain_days_ge1mm+" ngày mưa ≥1 mm, khoảng "+m.mean_rain_mm+" mm/tháng. Nhiệt độ trung bình "+m.mean_temperature_c+"°C.";
  $("season-baseline").textContent="ERA5 1991-2020 · tái phân tích ô lưới Dương Đông · không phải dự báo năm nay.";
  $("climate-months").replaceChildren(...[0,1,2].map(offset=>{
   const x=climate.months.find(x=>x.month===(month-1+offset)%12+1),e=document.createElement("div");
   e.className="climate-month";e.textContent="Tháng "+x.month+" · "+x.mean_temperature_c+"°C · "+x.mean_rain_mm+" mm · "+x.mean_rain_days_ge1mm+" ngày mưa";return e;
  }));
  document.querySelectorAll(".compare-item small")[0].textContent=m.mean_rain_mm+" mm/tháng";
  document.querySelectorAll(".compare-item small")[1].textContent=m.mean_temperature_c+"°C trung bình";
  document.querySelectorAll(".compare-item small")[2].textContent="Chưa có chuẩn sóng lịch sử";
  $("comparison").querySelector("h2").textContent="Thường lệ của tháng "+month;
 }
 $("future-detail").textContent=daily.length?"GEFS "+(daily[0]?.members||31)+" thành viên: xem trung vị, phân vị 90% và xác suất mưa trong chi tiết từng ngày. Chưa có đủ lịch sử đối chiếu tại Phú Quốc để công bố độ chính xác.":"Đang cập nhật phân bố dự báo.";
 const sat=op.satellite;
 $("satellite-status").textContent=sat?.status==="CURRENT"&&fresh(sat.sampled_time,40)?"Himawari 9 · "+time(sat.sampled_time)+" · đỉnh mây quan sát":"Đang cập nhật trường mây";
 const p=sat?.status==="CURRENT"&&fresh(sat.sampled_time,40)?sat?.points?.[region==="north"?"ganh_dau":region]:null;
 $("satellite-detail").textContent=p?"Mây đối lưu: "+({"HIGH":"tín hiệu mạnh","ELEVATED":"cần theo dõi","LOW":"tín hiệu thấp"}[p.convective_signal?.level]||"đang đối chiếu")+". Đây là tín hiệu đỉnh mây, không phải đo mưa hoặc sét.":"Mở lớp Mây trên bản đồ để xem vùng có dữ liệu.";
 $("weather-indicators").querySelector(".small-note").textContent="UV, tầm nhìn, áp suất: GFS · "+(good(ind)?time(ind.valid_at):'chưa có giờ hợp lệ')+". Không khí: CAMS · "+(good(aq)?time(aq.valid_at):'đang cập nhật')+". Chỉ số UV không có giới hạn tối đa 11.";
 $("sst-note").textContent="Ô lưới biển "+({duong_dong:"Dương Đông",an_thoi:"An Thới",north:"Bắc đảo"}[region])+" · "+(good(sst)?time(sst.valid_at):"đang cập nhật")+" · mô hình, không phải nhiệt kế tại bãi.";
}
$("area-picker")?.addEventListener("change",ev=>document.querySelector('[data-area="'+ev.target.value+'"]')?.click());
$("area-search")?.addEventListener("change",ev=>{const names={"Dương Đông":"duong_dong","An Thới":"an_thoi","Bắc đảo":"north"};const key=names[ev.target.value];if(key)document.querySelector('[data-area="'+key+'"]')?.click();else ev.target.setCustomValidity("Chọn Dương Đông, An Thới hoặc Bắc đảo.");if(key)ev.target.setCustomValidity("");});
window.addEventListener("openpq:render",ev=>{snapshot=ev.detail.data;region=ev.detail.region;render()});
if(window.openpqDisplaySnapshot){snapshot=window.openpqDisplaySnapshot.data;region=window.openpqDisplaySnapshot.region;render();}
})();
